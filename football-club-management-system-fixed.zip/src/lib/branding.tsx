"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

export type BrandingSettings = {
  siteName: string;
  shortName: string;
  adminName: string;
  portalName: string;
  tagline: string;
  logo: string;
};

export const defaultBranding: BrandingSettings = {
  siteName: "KULANANDAPUR FANTASTIC FC",
  shortName: "FANTASTIC FC",
  adminName: "FANTASTIC FC ADMIN",
  portalName: "FANTASTIC FC PORTAL",
  tagline: "EST. 2012 • ONE CLUB, ONE FAMILY",
  logo: "/logo-crest.png",
};

type BrandingContextValue = {
  branding: BrandingSettings;
  loading: boolean;
  refresh: () => Promise<void>;
  apply: (settings: BrandingSettings) => void;
};

const BrandingContext = createContext<BrandingContextValue | null>(null);

function updateDocumentBranding(settings: BrandingSettings) {
  document.title = settings.siteName;
  let icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
  if (!icon) {
    icon = document.createElement("link");
    icon.rel = "icon";
    document.head.appendChild(icon);
  }
  icon.href = settings.logo;
}

export function BrandingProvider({ children }: { children: ReactNode }) {
  const [branding, setBranding] = useState(defaultBranding);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/settings/branding", { cache: "no-store" });
      if (!response.ok) return;
      const data = await response.json() as { branding?: BrandingSettings };
      if (data.branding) { setBranding(data.branding); updateDocumentBranding(data.branding); }
    } catch {
      // The built-in identity remains available if settings cannot be loaded.
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  function apply(settings: BrandingSettings) {
    setBranding(settings);
    updateDocumentBranding(settings);
  }

  return <BrandingContext.Provider value={{ branding, loading, refresh, apply }}>{children}</BrandingContext.Provider>;
}

export function useBranding() {
  const context = useContext(BrandingContext);
  if (!context) throw new Error("useBranding must be used inside BrandingProvider");
  return context;
}
