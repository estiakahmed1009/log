export type Language = "bn" | "en";
export type Position = "GOALKEEPER" | "DEFENDER" | "MIDFIELDER" | "FORWARD";

export type Player = {
  id: number;
  name: string;
  nameBn: string;
  short: string;
  jersey: number;
  position: Position;
  image: string;
  matches: number;
  goals: number;
  assists: number;
  rating: number;
  captain?: boolean;
};

export const images = {
  hero: "https://images.pexels.com/photos/38881103/pexels-photo-38881103.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920",
  stadium: "https://images.pexels.com/photos/28827841/pexels-photo-28827841.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  family: "https://images.pexels.com/photos/16651538/pexels-photo-16651538.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  action: "https://images.pexels.com/photos/38089483/pexels-photo-38089483.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  rain: "https://images.pexels.com/photos/38881104/pexels-photo-38881104.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  ball: "https://images.pexels.com/photos/23848612/pexels-photo-23848612.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
};

export const playerImages = [
  "https://images.pexels.com/photos/21222661/pexels-photo-21222661.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
  "https://images.pexels.com/photos/37455463/pexels-photo-37455463.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
  "https://images.pexels.com/photos/35137933/pexels-photo-35137933.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
  "https://images.pexels.com/photos/37383526/pexels-photo-37383526.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
  "https://images.pexels.com/photos/27642308/pexels-photo-27642308.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
  "https://images.pexels.com/photos/35215190/pexels-photo-35215190.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=650",
];

export const players: Player[] = [
  { id: 1, name: "Rafiul Islam", nameBn: "রাফিউল ইসলাম", short: "RAFI", jersey: 1, position: "GOALKEEPER", image: playerImages[0], matches: 46, goals: 0, assists: 2, rating: 8.6 },
  { id: 2, name: "Mahin Chowdhury", nameBn: "মাহিন চৌধুরী", short: "MAHIN", jersey: 4, position: "DEFENDER", image: playerImages[1], matches: 52, goals: 4, assists: 8, rating: 8.3 },
  { id: 3, name: "Tanvir Ahmed", nameBn: "তানভীর আহমেদ", short: "TANVIR", jersey: 5, position: "DEFENDER", image: playerImages[2], matches: 41, goals: 3, assists: 5, rating: 8.1 },
  { id: 4, name: "Shakil Hossain", nameBn: "শাকিল হোসেন", short: "SHAKIL", jersey: 8, position: "MIDFIELDER", image: playerImages[3], matches: 58, goals: 14, assists: 23, rating: 9.0, captain: true },
  { id: 5, name: "Nafis Rahman", nameBn: "নাফিস রহমান", short: "NAFIS", jersey: 10, position: "MIDFIELDER", image: playerImages[4], matches: 49, goals: 19, assists: 17, rating: 8.8 },
  { id: 6, name: "Siam Khan", nameBn: "সিয়াম খান", short: "SIAM", jersey: 11, position: "FORWARD", image: playerImages[5], matches: 44, goals: 31, assists: 12, rating: 9.2 },
  { id: 7, name: "Arafat Hossain", nameBn: "আরাফাত হোসেন", short: "ARAFAT", jersey: 7, position: "FORWARD", image: playerImages[1], matches: 38, goals: 22, assists: 15, rating: 8.7 },
  { id: 8, name: "Mehedi Hasan", nameBn: "মেহেদী হাসান", short: "MEHEDI", jersey: 6, position: "MIDFIELDER", image: playerImages[2], matches: 47, goals: 8, assists: 20, rating: 8.5 },
];

export const publicNav = [
  { href: "/", en: "Home", bn: "হোম" },
  { href: "/about", en: "Club", bn: "ক্লাব" },
  { href: "/players", en: "Players", bn: "খেলোয়াড়" },
  { href: "/matches", en: "Matches", bn: "ম্যাচ" },
  { href: "/tournaments", en: "Tournaments", bn: "টুর্নামেন্ট" },
  { href: "/news", en: "News", bn: "সংবাদ" },
  { href: "/gallery", en: "Gallery", bn: "গ্যালারি" },
  { href: "/contact", en: "Contact", bn: "যোগাযোগ" },
];

export const memberNav = [
  ["/member", "Dashboard", "ড্যাশবোর্ড", "LayoutDashboard"],
  ["/member/profile", "My Profile", "আমার প্রোফাইল", "UserRound"],
  ["/member/team", "Our Team", "আমাদের দল", "UsersRound"],
  ["/member/members", "Members", "সদস্যবৃন্দ", "Users"],
  ["/member/matches", "Matches", "ম্যাচ", "Swords"],
  ["/member/fixtures", "Fixtures", "ফিক্সচার", "CalendarDays"],
  ["/member/tournaments", "Tournaments", "টুর্নামেন্ট", "Trophy"],
  ["/member/payments", "Make Payment", "পেমেন্ট করুন", "CreditCard"],
  ["/member/payment-history", "Payment History", "পেমেন্ট ইতিহাস", "ReceiptText"],
  ["/member/finance", "Club Finance", "ক্লাব ফাইন্যান্স", "ChartNoAxesCombined"],
  ["/member/fund", "Club Fund", "ক্লাব ফান্ড", "HandCoins"],
  ["/member/news", "Club News", "ক্লাব সংবাদ", "Newspaper"],
  ["/member/announcements", "Announcements", "ঘোষণা", "Megaphone"],
  ["/member/notifications", "Notifications", "নোটিফিকেশন", "Bell"],
  ["/member/documents", "Documents", "ডকুমেন্ট", "FolderDown"],
  ["/member/settings", "Settings", "সেটিংস", "Settings"],
] as const;

export const adminNav = [
  ["/admin", "Dashboard", "ড্যাশবোর্ড", "LayoutDashboard"],
  ["/admin/members", "Members", "সদস্য", "Users"],
  ["/admin/players", "Players", "খেলোয়াড়", "CircleUserRound"],
  ["/admin/approvals", "Member Approvals", "সদস্য অনুমোদন", "UserCheck"],
  ["/admin/jersey", "Jersey Orders", "জার্সি অর্ডার", "Shirt"],
  ["/admin/field", "Field & Lineup", "ফিল্ড ও লাইনআপ", "Goal"],
  ["/admin/pin-resets", "PIN Resets", "পিন রিসেট", "KeyRound"],
  ["/admin/tournament-apps", "Tournament Apps", "টুর্নামেন্ট আবেদন", "ClipboardList"],
  ["/admin/admin-notifications", "Notifications", "নোটিফিকেশন", "Bell"],
  ["/admin/audit", "Audit Log", "অডিট লগ", "History"],
  ["/admin/payments", "Payments", "পেমেন্ট", "CreditCard"],
  ["/admin/verification", "Verification", "ভেরিফিকেশন", "BadgeCheck"],
  ["/admin/financial", "Financial", "ফাইন্যান্স", "ChartNoAxesCombined"],
  ["/admin/fund", "Club Fund", "ক্লাব ফান্ড", "Landmark"],
  ["/admin/expenses", "Expenses", "খরচ", "Receipt"],
  ["/admin/payment-methods", "Payment Methods", "পেমেন্ট মাধ্যম", "WalletCards"],
  ["/admin/fees", "Fee Structure", "ফি নির্ধারণ", "Coins"],
  ["/admin/matches", "Matches", "ম্যাচ", "Swords"],
  ["/admin/fixtures", "Fixtures", "ফিক্সচার", "CalendarDays"],
  ["/admin/tournaments", "Tournaments", "টুর্নামেন্ট", "Trophy"],
  ["/admin/news", "News", "সংবাদ", "Newspaper"],
  ["/admin/gallery", "Gallery", "গ্যালারি", "Images"],
  ["/admin/announcements", "Announcements", "ঘোষণা", "Megaphone"],
  ["/admin/banners", "Banners", "ব্যানার", "PanelsTopLeft"],
  ["/admin/logos", "Logos & Media", "লোগো ও মিডিয়া", "ImageUp"],
  ["/admin/documents", "Documents", "ডকুমেন্ট", "FolderDown"],
  ["/admin/admin-users", "Admin Users", "অ্যাডমিন ইউজার", "ShieldCheck"],
  ["/admin/settings", "Settings", "সেটিংস", "Settings"],
  ["/admin/security", "Admin Login & Security", "অ্যাডমিন লগইন ও নিরাপত্তা", "LockKeyhole"],
] as const;

export const fixtures = [
  { date: "28", month: "JUN", competition: "KPL • GROUP A", home: "Fantastic FC", away: "Green Warriors", time: "4:30 PM", venue: "Kulanandapur School Field", state: "UPCOMING" },
  { date: "05", month: "JUL", competition: "FRIENDLY", home: "Rising Stars", away: "Fantastic FC", time: "5:00 PM", venue: "Central Sports Ground", state: "UPCOMING" },
  { date: "12", month: "JUL", competition: "KPL • GROUP A", home: "Fantastic FC", away: "Thunder Eleven", time: "4:15 PM", venue: "Kulanandapur School Field", state: "UPCOMING" },
];

export const results = [
  { date: "14 JUN", competition: "KPL • MATCHDAY 02", home: "Fantastic FC", away: "Brothers United", homeScore: 3, awayScore: 1, state: "FULL TIME" },
  { date: "07 JUN", competition: "FRIENDLY", home: "Young Lions", away: "Fantastic FC", homeScore: 2, awayScore: 2, state: "FULL TIME" },
  { date: "31 MAY", competition: "KPL • MATCHDAY 01", home: "Fantastic FC", away: "Unity Club", homeScore: 2, awayScore: 0, state: "FULL TIME" },
];

export const news = [
  { id: 1, category: "CLUB NEWS", title: "Fantastic FC begins a bold new chapter", titleBn: "নতুন অধ্যায়ে পা রাখল ফ্যান্টাস্টিক এফসি", date: "18 June 2025", image: images.family, excerpt: "A stronger squad, renewed ambition and one shared dream for the season ahead." },
  { id: 2, category: "MATCH REPORT", title: "Three goals seal a commanding home win", titleBn: "তিন গোলে দুর্দান্ত জয় নিশ্চিত", date: "15 June 2025", image: images.action, excerpt: "A complete team performance brought all three points home under the lights." },
  { id: 3, category: "COMMUNITY", title: "Building the future through grassroots football", titleBn: "তৃণমূল ফুটবলে ভবিষ্যৎ গড়ার উদ্যোগ", date: "10 June 2025", image: images.rain, excerpt: "Our youth program welcomed thirty aspiring footballers from the local community." },
];

export const gallery = [images.hero, images.action, images.family, images.rain, images.stadium, images.ball];

export const paymentMethods = [
  { id: 1, name: "bKash", number: "017•••••427", account: "Fantastic FC", enabled: true, color: "#e2136e" },
  { id: 2, name: "Nagad", number: "018•••••965", account: "Fantastic FC", enabled: true, color: "#f15b2a" },
  { id: 3, name: "Upay", number: "016•••••582", account: "Fantastic FC", enabled: true, color: "#f59e0b" },
  { id: 4, name: "Rocket", number: "019•••••318", account: "Fantastic FC", enabled: true, color: "#8c3494" },
  { id: 5, name: "Visa", number: "Card payment", account: "Fantastic FC", enabled: true, color: "#1a5cb0" },
];

export const paymentHistory = [
  { id: "PAY-24018", date: "12 Jun 2025", type: "Monthly fee — June", method: "bKash", amount: 500, status: "PAID" },
  { id: "PAY-23988", date: "02 Jun 2025", type: "Tournament fee", method: "Nagad", amount: 1000, status: "PENDING" },
  { id: "PAY-23742", date: "12 May 2025", type: "Monthly fee — May", method: "Visa", amount: 500, status: "PAID" },
  { id: "PAY-23611", date: "08 May 2025", type: "Jersey payment", method: "Rocket", amount: 850, status: "REJECTED" },
];

export const memberNotices = [
  { title: "Match squad published", body: "The 18-player squad for Friday is now available.", time: "12 min ago", type: "team" },
  { title: "Payment verified", body: "Your June monthly fee has been verified.", time: "Yesterday", type: "payment" },
  { title: "Training schedule updated", body: "Thursday's session begins at 5:00 PM.", time: "2 days ago", type: "event" },
];

export const documents = [
  { title: "Club Constitution 2025", category: "Official", type: "PDF", size: "1.8 MB", date: "10 Jun 2025" },
  { title: "KPL Tournament Rules", category: "Tournament", type: "PDF", size: "820 KB", date: "04 Jun 2025" },
  { title: "Member Code of Conduct", category: "Member", type: "DOCX", size: "340 KB", date: "22 May 2025" },
];

export const financeRows: { month: string; collection: number; expense: number; balance: number; verified: boolean }[] = [];

export const adminMembers = [
  { id: "FFC-0021", name: "Sabbir Ahmed", mobile: "01712-345678", jersey: 17, position: "Forward", joined: "14 Jun 2025", status: "PENDING", image: playerImages[1] },
  { id: "FFC-0020", name: "Fahim Rahman", mobile: "01813-452890", jersey: 14, position: "Midfielder", joined: "12 Jun 2025", status: "ACTIVE", image: playerImages[2] },
  { id: "FFC-0019", name: "Imran Hossain", mobile: "01914-625371", jersey: 3, position: "Defender", joined: "08 Jun 2025", status: "ACTIVE", image: playerImages[3] },
  { id: "FFC-0018", name: "Adnan Kabir", mobile: "01615-934276", jersey: 21, position: "Forward", joined: "02 Jun 2025", status: "INACTIVE", image: playerImages[4] },
];

export const auditRows = [
  { actor: "Super Admin", action: "Payment approved", target: "PAY-24018 • Rafiul Islam", time: "18 Jun, 10:42 AM", tone: "green" },
  { actor: "Nayeem Admin", action: "Member approved", target: "FFC-0020 • Fahim Rahman", time: "18 Jun, 09:18 AM", tone: "blue" },
  { actor: "Super Admin", action: "Lineup updated", target: "KPL Matchday 03", time: "17 Jun, 08:25 PM", tone: "amber" },
  { actor: "Media Admin", action: "Banner added", target: "Season 2025 campaign", time: "17 Jun, 04:10 PM", tone: "violet" },
];
