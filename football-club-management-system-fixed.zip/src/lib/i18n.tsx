"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Language } from "./club-data";

type I18nValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  tr: (english: string, bangla: string) => string;
};

const I18nContext = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en");

  useEffect(() => {
    const saved = window.localStorage.getItem("ffc-language");
    if (saved === "bn" || saved === "en") setLanguageState(saved);
  }, []);

  function setLanguage(next: Language) {
    setLanguageState(next);
    window.localStorage.setItem("ffc-language", next);
    document.documentElement.lang = next === "bn" ? "bn" : "en";
  }

  const tr = (english: string, bangla: string) => language === "bn" ? bangla : english;

  return (
    <I18nContext.Provider value={{ language, setLanguage, tr }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const value = useContext(I18nContext);
  if (!value) throw new Error("useI18n must be used inside I18nProvider");
  return value;
}
