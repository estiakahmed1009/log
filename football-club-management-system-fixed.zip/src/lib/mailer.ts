// Shared Resend email helper. Every route that needs to send an email (contact form
// auto-reply, tournament application receipt, admin notifications, PIN resets, etc.)
// should go through this so the RESEND_API_KEY / from-address logic lives in one place.

export function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character] || character);
}

export async function sendEmail(options: { to: string; subject: string; html: string }): Promise<{ status: "SENT" | "FAILED" | "SKIPPED"; providerId: string | null }> {
  const resendKey = process.env.RESEND_API_KEY;
  const from = process.env.ADMIN_EMAIL_FROM || "Fantastic FC <onboarding@resend.dev>";
  if (!resendKey) {
    // No API key configured yet — don't throw, just skip so the rest of the request still succeeds.
    console.warn("RESEND_API_KEY is not set; skipping email send to", options.to);
    return { status: "SKIPPED", providerId: null };
  }
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [options.to], subject: options.subject, html: options.html }),
    });
    const result = (await response.json().catch(() => ({}))) as { id?: string };
    if (response.ok) return { status: "SENT", providerId: result.id || null };
    console.error("Resend email failed", await response.text().catch(() => ""));
    return { status: "FAILED", providerId: null };
  } catch (error) {
    console.error("Email dispatch failed", error);
    return { status: "FAILED", providerId: null };
  }
}

export async function getAdminNotifyEmail(): Promise<string> {
  try {
    const { db } = await import("@/db");
    const { clubSettings } = await import("@/db/schema");
    const { eq } = await import("drizzle-orm");
    const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "adminAuth")).limit(1);
    const email = row?.value?.email;
    return typeof email === "string" && email ? email : "xlkfantastic@gmail.com";
  } catch {
    return "xlkfantastic@gmail.com";
  }
}
