"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ArrowRight, Award, CalendarDays, Camera, Check, ChevronDown, ChevronRight, CirclePlay,
  Clock3, Goal, LockKeyhole, Mail, MapPin, Menu, MessageCircle, MessagesSquare, Phone,
  Play, Quote, Share2, ShieldCheck, Target, Trophy, Upload, UserPlus, UserRound, Users,
  Video, X, Zap,
} from "lucide-react";
import { useEffect, useMemo, useState, type ChangeEvent, type CSSProperties, type FormEvent } from "react";
import {
  fixtures, gallery, images, playerImages, publicNav, results, type Position,
} from "@/lib/club-data";
import { useI18n } from "@/lib/i18n";
import { useBranding } from "@/lib/branding";
import { fallbackBanner, type ClubBanner } from "@/lib/banner";
import {
  Button, ClubLogo, ClubMark, FormMessage, LanguageSwitcher, Modal, PageHero, SectionTitle, StatusPill,
} from "./ui";

function PublicHeader() {
  const pathname = usePathname();
  const { language, tr } = useI18n();
  const [open, setOpen] = useState(false);
  const [accessOpen, setAccessOpen] = useState(false);
  return (
    <>
      <div className="public-topbar">
        <div className="site-container topbar-inner">
          <p><MapPin size={13}/> {tr("Kulanandapur, Bangladesh", "কুলানন্দপুর, বাংলাদেশ")} <span/> <Mail size={13}/> hello@fantasticfc.com</p>
          <div className="top-socials"><span>{tr("Follow the club", "ক্লাবকে অনুসরণ করুন")}</span><MessagesSquare/><Camera/><Video/></div>
        </div>
      </div>
      <header className="public-header">
        <div className="site-container header-inner">
          <ClubLogo />
          <nav className={open ? "main-nav open" : "main-nav"} aria-label="Main navigation">
            {publicNav.map(item => (
              <Link key={item.href} className={(pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))) ? "active" : ""} href={item.href} onClick={() => setOpen(false)}>
                {language === "bn" ? item.bn : item.en}
              </Link>
            ))}
            <Link className="mobile-access-link" href="/login?role=player" onClick={() => setOpen(false)}><UserRound/>{tr("Player / Member Login", "খেলোয়াড় / সদস্য লগইন")}</Link>
            <Link className="mobile-access-link admin" href="/login?role=admin" onClick={() => setOpen(false)}><ShieldCheck/>{tr("Admin Panel Login", "অ্যাডমিন প্যানেল লগইন")}</Link>
          </nav>
          <div className="header-actions">
            <LanguageSwitcher />
            <div className="access-menu">
              <button className="login-link" onClick={() => setAccessOpen(v => !v)} aria-expanded={accessOpen}>{tr("Login", "লগইন")}<ChevronDown/></button>
              {accessOpen && <div className="access-dropdown">
                <Link href="/login?role=player" onClick={() => setAccessOpen(false)}><span><UserRound/></span><div><b>{tr("Player / Member Login", "খেলোয়াড় / সদস্য লগইন")}</b><small>{tr("Open Fantastic FC Portal", "ফ্যান্টাস্টিক এফসি পোর্টাল খুলুন")}</small></div><ChevronRight/></Link>
                <Link href="/login?role=admin" onClick={() => setAccessOpen(false)}><span className="admin"><ShieldCheck/></span><div><b>{tr("Admin Panel Login", "অ্যাডমিন প্যানেল লগইন")}</b><small>{tr("Secure administration access", "নিরাপদ প্রশাসনিক প্রবেশ")}</small></div><ChevronRight/></Link>
              </div>}
            </div>
            <Button href="/register" icon={false}>{tr("Join the club", "ক্লাবে যোগ দিন")} <UserPlus size={16}/></Button>
            <button className="mobile-nav-button" onClick={() => setOpen(v => !v)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
          </div>
        </div>
      </header>
    </>
  );
}

function PublicFooter() {
  const { tr } = useI18n();
  const { branding } = useBranding();
  return (
    <footer className="public-footer">
      <div className="site-container footer-top">
        <div className="footer-brand"><ClubLogo inverse/><p>{tr("More than a football club. We are a family built on courage, respect and the love of the beautiful game.", "শুধু একটি ফুটবল ক্লাব নয়। সাহস, সম্মান এবং ফুটবলের ভালোবাসায় গড়ে ওঠা আমরা একটি পরিবার।")}</p><div className="footer-social"><MessagesSquare/><Camera/><Share2/><Video/></div></div>
        <div><h4>{tr("THE CLUB", "ক্লাব")}</h4><Link href="/about">{tr("About us", "আমাদের সম্পর্কে")}</Link><Link href="/players">{tr("First team", "প্রথম দল")}</Link><Link href="/news">{tr("Club news", "ক্লাব সংবাদ")}</Link><Link href="/contact">{tr("Contact", "যোগাযোগ")}</Link></div>
        <div><h4>{tr("MATCH CENTRE", "ম্যাচ সেন্টার")}</h4><Link href="/fixtures">{tr("Fixtures", "ফিক্সচার")}</Link><Link href="/results">{tr("Results", "ফলাফল")}</Link><Link href="/tournaments">{tr("Tournaments", "টুর্নামেন্ট")}</Link><Link href="/gallery">{tr("Gallery", "গ্যালারি")}</Link></div>
        <div className="footer-contact"><h4>{tr("VISIT US", "আমাদের ঠিকানা")}</h4><p><MapPin/> {tr("Kulanandapur School Field, Kushtia, Bangladesh", "কুলানন্দপুর স্কুল মাঠ, কুষ্টিয়া, বাংলাদেশ")}</p><p><Phone/> +880 1712-000000</p><p><Mail/> hello@fantasticfc.com</p></div>
      </div>
      <div className="site-container footer-bottom"><p>© 2025 {branding.siteName}. {tr("All rights reserved.", "সর্বস্বত্ব সংরক্ষিত।")}</p><div><Link href="/about">{tr("Privacy", "গোপনীয়তা")}</Link><Link href="/about">{tr("Terms", "শর্তাবলী")}</Link><Link href="/login?role=admin">{tr("Admin Login", "অ্যাডমিন লগইন")}</Link></div></div>
    </footer>
  );
}

type NextMatch = {
  id: string; opponentName: string; opponentLogoUrl: string | null; matchDatetime: string;
  competition: string | null; groupName: string | null; venue: string | null; homeAway: string;
};

function useCountdown(target: Date | null) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!target) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [target]);
  if (!target) return null;
  const diff = Math.max(0, target.getTime() - now);
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds, isPast: diff <= 0 };
}

function HomeHero() {
  const { tr } = useI18n();
  const { branding } = useBranding();
  const [banner, setBanner] = useState<ClubBanner>(fallbackBanner);
  const [match, setMatch] = useState<NextMatch | null>(null);
  const [matchLoaded, setMatchLoaded] = useState(false);
  useEffect(()=>{void (async()=>{try{const response=await fetch("/api/banners",{cache:"no-store"});const data=await response.json() as {banners?:ClubBanner[]};if(data.banners?.[0])setBanner(data.banners[0])}catch{/* Keep the premium fallback hero. */}})()},[]);
  useEffect(()=>{void (async()=>{try{const response=await fetch("/api/matches",{cache:"no-store"});const data=await response.json() as {match?:NextMatch|null};setMatch(data.match||null)}catch{setMatch(null)}finally{setMatchLoaded(true)}})()},[]);
  const titleLines=banner.title.split("\n").filter(Boolean);
  const heroVars={"--hero-img":`url(${banner.imageUrl})`,"--hero-img-mobile":`url(${banner.mobileImageUrl||banner.imageUrl})`,"--hero-pos":banner.imagePosition||"center 40%","--hero-pos-mobile":banner.mobileImagePosition||"65% center"} as CSSProperties;
  const matchDate=match?new Date(match.matchDatetime):null;
  const countdown=useCountdown(matchDate);
  const homeIsClub=!match||match.homeAway!=="AWAY";
  return (
    <>
    <section className="home-hero" style={heroVars}>
      <div className="hero-glow"/><div className="site-container hero-content">
        <div className="hero-kicker"><span className="live-dot"/>{banner.eyebrow}</div>
        <h1>{titleLines[0]}{titleLines.length>1&&<><br/><em>{titleLines.slice(1).join(" ")}</em></>}</h1>
        <p>{banner.subtitle}</p>
        <div className="hero-buttons"><Button href={banner.buttonLink}>{banner.buttonText}</Button><Button href="/about" variant="ghost"><CirclePlay size={18}/>{tr("Discover our story", "আমাদের গল্প জানুন")}</Button></div>
        <div className="hero-mini-stats"><div><strong>2012</strong><span>{tr("FOUNDED", "প্রতিষ্ঠিত")}</span></div><div><strong>42+</strong><span>{tr("ACTIVE MEMBERS", "সক্রিয় সদস্য")}</span></div><div><strong>09</strong><span>{tr("TROPHIES", "ট্রফি")}</span></div><div><strong>87%</strong><span>{tr("WIN RATE", "জয়ের হার")}</span></div></div>
      </div>
    </section>
    <section className="next-match-section">
      <div className="site-container">
        {!matchLoaded?null:!match?(
          <div className="hero-next-match empty">
            <div className="match-ribbon"><span>{tr("NEXT MATCH", "পরবর্তী ম্যাচ")}</span></div>
            <p className="next-match-empty-text">{tr("No upcoming match scheduled yet. Check back soon.","এখনো কোনো ম্যাচ নির্ধারিত হয়নি। শীঘ্রই দেখুন।")}</p>
          </div>
        ):(
          <div className="hero-next-match">
            <div className="match-ribbon"><span>{tr("NEXT MATCH", "পরবর্তী ম্যাচ")}</span>{(match.competition||match.groupName)&&<b>{match.competition}{match.competition&&match.groupName&&" • "}{match.groupName}</b>}</div>
            <div className="hero-match-teams">
              <div>{homeIsClub?<ClubMark alt="Club crest"/>:<span className="opponent-logo-box">{match.opponentLogoUrl?<img src={match.opponentLogoUrl} alt={match.opponentName}/>:<span className="opponent-mark">{match.opponentName.slice(0,2).toUpperCase()}</span>}</span>}<span>{homeIsClub?branding.shortName:match.opponentName}</span></div>
              <p><strong>{matchDate?matchDate.getDate():"--"}</strong><b>{matchDate?matchDate.toLocaleDateString("en-GB",{month:"short"}).toUpperCase():""}</b><small>{matchDate?matchDate.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:true}):""}</small></p>
              <div>{!homeIsClub?<ClubMark alt="Club crest"/>:<span className="opponent-logo-box">{match.opponentLogoUrl?<img src={match.opponentLogoUrl} alt={match.opponentName}/>:<span className="opponent-mark">{match.opponentName.slice(0,2).toUpperCase()}</span>}</span>}<span>{!homeIsClub?branding.shortName:match.opponentName}</span></div>
            </div>
            {countdown&&!countdown.isPast&&<div className="match-countdown"><div><strong>{String(countdown.days).padStart(2,"0")}</strong><span>{tr("DAYS","দিন")}</span></div><em>:</em><div><strong>{String(countdown.hours).padStart(2,"0")}</strong><span>{tr("HOURS","ঘণ্টা")}</span></div><em>:</em><div><strong>{String(countdown.minutes).padStart(2,"0")}</strong><span>{tr("MINUTES","মিনিট")}</span></div><em>:</em><div><strong>{String(countdown.seconds).padStart(2,"0")}</strong><span>{tr("SECONDS","সেকেন্ড")}</span></div></div>}
            <div className="hero-match-foot">{match.venue&&<><MapPin size={13}/>{match.venue}</>}<Link href="/fixtures">{tr("All fixtures", "সব ফিক্সচার")}<ArrowRight size={14}/></Link></div>
          </div>
        )}
      </div>
    </section>
    </>
  );
}
function FixtureStrip() {
  const { tr } = useI18n();
  return (
    <section className="fixture-strip"><div className="site-container fixture-strip-inner">
      <div className="strip-title"><span>{tr("MATCH CENTRE", "ম্যাচ সেন্টার")}</span><b>{tr("Upcoming fixtures", "আসন্ন ফিক্সচার")}</b></div>
      {fixtures.slice(0, 2).map((f, i) => <div className="mini-fixture" key={f.date}><div className="mini-date"><b>{f.date}</b><span>{f.month}</span></div><div><small>{f.competition}</small><strong>{f.home} <em>VS</em> {f.away}</strong><p><Clock3/> {f.time} <MapPin/> {f.venue}</p></div>{i === 0 && <StatusPill status="UPCOMING"/>}</div>)}
      <Link className="round-link" href="/fixtures"><ArrowRight/></Link>
    </div></section>
  );
}

type SquadMember={id:string;name:string;image:string;jersey:number;position:string;captain:boolean;matches:number;goals:number;assists:number;rating:string};

function useSquad(){
  const [squad,setSquad]=useState<SquadMember[]>([]);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{let cancelled=false;(async()=>{try{
    const res=await fetch("/api/squad",{cache:"no-store"});
    const data=await res.json() as {squad?:Array<{id:string;name:string;jersey:number;position:string;photo:string|null;isCaptain:boolean;matchesPlayed:number;goals:number;assists:number;rating:string|null}>};
    if(!cancelled)setSquad((data.squad||[]).map((m,i)=>({id:m.id,name:m.name,image:m.photo||playerImages[i%playerImages.length],jersey:m.jersey,position:m.position,captain:m.isCaptain,matches:m.matchesPlayed,goals:m.goals,assists:m.assists,rating:m.rating||"—"})));
  }catch{ /* best-effort */ }finally{if(!cancelled)setLoading(false)}})();return()=>{cancelled=true}},[]);
  return {squad,loading};
}

type LineupSlotMember={id:string;name:string;jersey:number;position:string;photo:string|null;rating:string|null};
function useLineup(){
  const [lineup,setLineup]=useState<{teamName:string;matchTitle:string;formation:string;players:Array<{slot:string;member:LineupSlotMember|null}>}|null>(null);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{let cancelled=false;(async()=>{try{
    const res=await fetch("/api/lineup",{cache:"no-store"});
    const data=await res.json() as {lineup:typeof lineup};
    if(!cancelled)setLineup(data.lineup);
  }catch{ /* best-effort */ }finally{if(!cancelled)setLoading(false)}})();return()=>{cancelled=true}},[]);
  return {lineup,loading};
}

export function Pitch({ onPlayer }: { onPlayer?: (player: SquadMember) => void }) {
  const {lineup}=useLineup();
  const base=["GK","LB","LCB","RCB","RB","LCM","CM","RCM","LW","ST","RW"];
  const coords=[[50,88],[18,67],[39,71],[61,71],[82,67],[27,45],[50,50],[73,45],[21,20],[50,14],[79,20]];
  const bySlot=new Map((lineup?.players||[]).map(p=>[p.slot,p.member]));
  return (
    <div className="football-pitch">
      <div className="pitch-lines"><i className="half"/><i className="circle"/><i className="box top"/><i className="box bottom"/></div>
      {base.map((slot,i)=>{
        const m=bySlot.get(slot);
        return <button key={slot} className={`pitch-player ${m?"filled":"empty"}`} style={{ left: `${coords[i][0]}%`, top: `${coords[i][1]}%` }} onClick={()=>m&&onPlayer?.({id:m.id,name:m.name,image:m.photo||"",jersey:m.jersey,position:m.position,captain:false,matches:0,goals:0,assists:0,rating:m.rating||"—"})}>
          {m ? <><span className="pitch-avatar"><img src={m.photo||""} alt={m.name}/><b>{m.jersey}</b></span><strong>{m.name.split(" ")[0]}</strong>{m.rating&&<small>{m.rating}</small>}</> : <><span className="pitch-empty">+</span><strong>{slot}</strong></>}
        </button>;
      })}
    </div>
  );
}

function PlayerModal({ player, close }: { player: SquadMember | null; close: () => void }) {
  const { tr } = useI18n();
  return <Modal open={!!player} onClose={close}>{player && <div className="player-modal">
    <div className="player-modal-photo"><img src={player.image} alt={player.name}/><span>{player.jersey}</span></div>
    <div className="player-modal-body"><div className="eyebrow"><span/>{player.position}</div><h2>{player.name}</h2>{player.captain && <span className="captain-tag"><ShieldCheck/> {tr("CLUB CAPTAIN", "ক্লাব অধিনায়ক")}</span>}
      <p>{tr("A committed team player representing Kulanandapur with pride, discipline and courage on every matchday.", "প্রতিটি ম্যাচে গর্ব, শৃঙ্খলা ও সাহসের সঙ্গে কুলানন্দপুরকে প্রতিনিধিত্ব করা একজন নিবেদিত খেলোয়াড়।")}</p>
      <div className="player-stats"><div><strong>{player.matches}</strong><span>{tr("Matches", "ম্যাচ")}</span></div><div><strong>{player.goals}</strong><span>{tr("Goals", "গোল")}</span></div><div><strong>{player.assists}</strong><span>{tr("Assists", "অ্যাসিস্ট")}</span></div><div><strong>{player.rating}</strong><span>{tr("Rating", "রেটিং")}</span></div></div>
    </div>
  </div>}</Modal>;
}

function HomePage() {
  const { tr } = useI18n();
  const [selected, setSelected] = useState<SquadMember | null>(null);
  const {squad}=useSquad();
  return <>
    <HomeHero/><FixtureStrip/>
    <section className="section intro-section"><div className="site-container intro-grid"><div className="intro-images"><img className="intro-main" src={images.action} alt="Football action"/><div className="intro-float"><strong>13</strong><span>{tr("YEARS OF\nTHE JOURNEY", "১৩ বছরের\nপথচলা")}</span></div><img className="intro-small" src={images.ball} alt="Football on the pitch"/></div><div className="intro-copy"><div className="eyebrow"><span/>{tr("THIS IS FANTASTIC FC", "এটাই ফ্যান্টাস্টিক এফসি")}</div><h2>{tr("ROOTED IN COMMUNITY.", "শিকড়ে আমাদের সমাজ।")}<br/><em>{tr("DRIVEN BY THE GAME.", "প্রেরণায় ফুটবল।")}</em></h2><p>{tr("Born in the fields of Kulanandapur, Fantastic FC is where local talent, lifelong friendship and the pursuit of excellence come together.", "কুলানন্দপুরের মাঠে জন্ম নেওয়া ফ্যান্টাস্টিক এফসি—স্থানীয় প্রতিভা, আজীবন বন্ধুত্ব এবং শ্রেষ্ঠত্বের সাধনার মিলনস্থল।")}</p><div className="values-row"><div><ShieldCheck/><b>{tr("DISCIPLINE", "শৃঙ্খলা")}</b></div><div><Users/><b>{tr("BROTHERHOOD", "ভ্রাতৃত্ব")}</b></div><div><Target/><b>{tr("AMBITION", "লক্ষ্য")}</b></div></div><Button href="/about" variant="dark">{tr("Our club story", "ক্লাবের গল্প")}</Button></div></div></section>
    {squad.length>0&&<section className="section players-home"><div className="site-container"><SectionTitle eyebrow="THE FIRST TEAM" eyebrowBn="প্রথম দল" title="MEET THE FANTASTIC ONES" titleBn="আমাদের দুর্দান্ত খেলোয়াড়েরা" body="The people who carry our crest, our values and our ambition onto the pitch." bodyBn="যারা আমাদের ব্যাজ, মূল্যবোধ এবং স্বপ্ন মাঠে বয়ে নিয়ে যায়।" action={<Button href="/players" variant="outline">{tr("View full squad", "সম্পূর্ণ দল দেখুন")}</Button>}/><div className="player-cards home">{squad.slice(0,4).map(p => <button className="player-card" key={p.id} onClick={() => setSelected(p)}><img src={p.image} alt={p.name}/><span className="jersey-watermark">{String(p.jersey).padStart(2,"0")}</span><div className="player-card-copy"><small>{p.position}</small><h3>{p.name}</h3><p>#{p.jersey} {p.captain && `• ${tr("CAPTAIN", "অধিনায়ক")}`}</p></div><i><ArrowRight/></i></button>)}</div></div></section>}
    <section className="section lineup-section"><div className="site-container lineup-grid"><div className="lineup-copy"><div className="eyebrow light"><span/>{tr("MATCHDAY XI", "ম্যাচডে একাদশ")}</div><h2>{tr("OUR STARTING", "আমাদের শুরুর")}<br/><em>{tr("LINEUP", "একাদশ")}</em></h2><p>{tr("The published starting lineup. Tap any player to see the profile.", "প্রকাশিত শুরুর একাদশ। প্রোফাইল দেখতে খেলোয়াড়ে ট্যাপ করুন।")}</p><Button href="/team" variant="ghost">{tr("View team details", "দলের বিস্তারিত")}</Button></div><div className="pitch-wrap"><div className="pitch-top"><span>{tr("FANTASTIC FC • STARTING XI", "ফ্যান্টাস্টিক এফসি • প্রথম একাদশ")}</span></div><Pitch onPlayer={setSelected}/></div></div></section>
    <section className="section family-section"><div className="site-container"><div className="family-card" style={{ backgroundImage: `linear-gradient(90deg,rgba(3,16,12,.9),rgba(3,16,12,.16)),url(${images.family})` }}><div><div className="eyebrow light"><span/>{tr("MORE THAN A TEAM", "একটি দলের চেয়েও বেশি")}</div><h2>{tr("THE FANTASTIC", "দ্য ফ্যান্টাস্টিক")}<br/><em>{tr("FAMILY", "ফ্যামিলি")}</em></h2><p>{tr("Every match, every memory, every milestone—together.", "প্রতিটি ম্যাচ, প্রতিটি স্মৃতি, প্রতিটি অর্জন—একসঙ্গে।")}</p><Button href="/gallery">{tr("Explore our gallery", "গ্যালারি দেখুন")}</Button></div><Quote/></div></div></section>
    <section className="section latest-news"><div className="site-container"><SectionTitle eyebrow="FROM THE CLUB" eyebrowBn="ক্লাব থেকে" title="LATEST STORIES" titleBn="সর্বশেষ সংবাদ" action={<Button href="/news" variant="outline">{tr("All news", "সব সংবাদ")}</Button>}/><NewsGrid limit={3}/></div></section>
    <section className="join-cta"><div className="site-container join-inner"><div><span>{tr("WE ARE ONE CLUB", "আমরা এক ক্লাব")}</span><h2>{tr("READY TO BE FANTASTIC?", "ফ্যান্টাস্টিক হতে প্রস্তুত?")}</h2><p>{tr("Join the family. Wear the badge. Make your mark.", "পরিবারে যোগ দিন। ব্যাজ পরুন। নিজের ছাপ রাখুন।")}</p></div><Button href="/register" variant="primary">{tr("Start your journey", "যাত্রা শুরু করুন")}</Button></div></section>
    <PlayerModal player={selected} close={() => setSelected(null)}/>
  </>;
}

function AboutPage() {
  const { tr } = useI18n();
  return <><PageHero eyebrow="OUR IDENTITY" eyebrowBn="আমাদের পরিচয়" title="THE CLUB" titleBn="আমাদের ক্লাব" body="From a village field to a badge that brings a community together." bodyBn="গ্রামের মাঠ থেকে পুরো সমাজকে এক করা একটি ব্যাজের গল্প।" image={images.family}/>
    <section className="section"><div className="site-container story-grid"><div><SectionTitle eyebrow="OUR STORY" eyebrowBn="আমাদের গল্প" title="FOOTBALL LIVES HERE" titleBn="এখানে ফুটবল বেঁচে থাকে"/><p className="lead-copy">{tr("Fantastic FC began in 2012 with one ball, an open field and a group of friends who believed football could build something lasting. Today that belief connects players, members and supporters across Kulanandapur.", "২০১২ সালে একটি বল, একটি খোলা মাঠ এবং কিছু বন্ধুর স্বপ্ন নিয়ে ফ্যান্টাস্টিক এফসির যাত্রা শুরু। আজ সেই বিশ্বাস কুলানন্দপুরের খেলোয়াড়, সদস্য ও সমর্থকদের একসূত্রে বেঁধেছে।")}</p><p>{tr("We compete to win, but our greater purpose is to create opportunity, character and belonging through the game we love.", "আমরা জয়ের জন্য খেলি, তবে আমাদের বড় লক্ষ্য হলো প্রিয় খেলার মাধ্যমে সুযোগ, চরিত্র ও আপনত্ব তৈরি করা।")}</p></div><div className="story-image"><img src={images.rain} alt="Club history"/><span><b>2012</b>{tr("THE JOURNEY BEGAN", "যাত্রার শুরু")}</span></div></div></section>
    <section className="section mission-section"><div className="site-container mission-grid"><div><Target/><small>{tr("OUR MISSION", "আমাদের লক্ষ্য")}</small><h3>{tr("Develop people through football", "ফুটবলের মাধ্যমে মানুষ গড়া")}</h3><p>{tr("Create a disciplined, inclusive environment where every player can grow.", "শৃঙ্খলাবদ্ধ, অন্তর্ভুক্তিমূলক পরিবেশে প্রতিটি খেলোয়াড়ের বিকাশ নিশ্চিত করা।")}</p></div><div><Zap/><small>{tr("OUR VISION", "আমাদের স্বপ্ন")}</small><h3>{tr("Be the region's model community club", "অঞ্চলের আদর্শ কমিউনিটি ক্লাব হওয়া")}</h3><p>{tr("Set a standard for sporting excellence, trust and sustainable club management.", "ক্রীড়া উৎকর্ষ, আস্থা ও টেকসই ক্লাব পরিচালনায় মানদণ্ড স্থাপন করা।")}</p></div><div><ShieldCheck/><small>{tr("OUR VALUES", "আমাদের মূল্যবোধ")}</small><h3>{tr("Respect. Courage. Brotherhood.", "সম্মান। সাহস। ভ্রাতৃত্ব।")}</h3><p>{tr("The principles behind every decision, every training session and every match.", "প্রতিটি সিদ্ধান্ত, অনুশীলন ও ম্যাচের পেছনে থাকা মূলনীতি।")}</p></div></div></section>
    <section className="section achievements"><div className="site-container"><SectionTitle eyebrow="OUR HONOURS" eyebrowBn="আমাদের সম্মাননা" title="BUILT TO COMPETE" titleBn="প্রতিযোগিতার জন্য গড়া" center/><div className="honour-grid">{[["04","LEAGUE TITLES","লিগ শিরোপা"],["03","KNOCKOUT CUPS","নকআউট কাপ"],["02","COMMUNITY SHIELDS","কমিউনিটি শিল্ড"],["13","YEARS TOGETHER","একসঙ্গে বছর"]].map(x => <div key={x[1]}><Trophy/><strong>{x[0]}</strong><span>{tr(x[1],x[2])}</span></div>)}</div></div></section></>;
}

function PlayersPage() {
  const { tr } = useI18n();
  const [filter, setFilter] = useState<"ALL"|Position>("ALL");
  const [selected, setSelected] = useState<SquadMember|null>(null);
  const {squad,loading}=useSquad();
  const list = useMemo(() => filter === "ALL" ? squad : squad.filter(p => p.position === filter), [filter,squad]);
  const labels: Array<["ALL"|Position,string,string]> = [["ALL","ALL","সব"],["GOALKEEPER","GOALKEEPERS","গোলকিপার"],["DEFENDER","DEFENDERS","ডিফেন্ডার"],["MIDFIELDER","MIDFIELDERS","মিডফিল্ডার"],["FORWARD","FORWARDS","ফরোয়ার্ড"]];
  return <><PageHero eyebrow="THE SQUAD" eyebrowBn="দল" title="FIRST TEAM" titleBn="প্রথম দল" body="Meet the players who represent the Fantastic badge." bodyBn="যারা ফ্যান্টাস্টিক ব্যাজকে প্রতিনিধিত্ব করেন তাদের জানুন।" image={images.action}/><section className="section"><div className="site-container"><div className="filter-row">{labels.map(([value,en,bn]) => <button key={value} className={filter === value ? "active" : ""} onClick={() => setFilter(value)}>{tr(en,bn)}<span>{value === "ALL" ? squad.length : squad.filter(p=>p.position===value).length}</span></button>)}</div>{!loading&&squad.length===0?<div className="empty-table" style={{padding:"40px 0"}}><p>{tr("No squad players published yet.","এখনো কোনো স্কোয়াড খেলোয়াড় প্রকাশিত হয়নি।")}</p></div>:<div className="player-cards roster">{list.map(p => <button className="player-card" key={p.id} onClick={() => setSelected(p)}><img src={p.image} alt={p.name}/><span className="jersey-watermark">{String(p.jersey).padStart(2,"0")}</span><div className="player-card-copy"><small>{p.position}</small><h3>{p.name}</h3><p>#{p.jersey} {p.captain && `• ${tr("CAPTAIN", "অধিনায়ক")}`}</p></div><i><ArrowRight/></i></button>)}</div>}</div></section><PlayerModal player={selected} close={() => setSelected(null)}/></>;
}

function MatchesPage({ mode }: { mode: "all"|"fixtures"|"results" }) {
  const { tr } = useI18n();
  return <><PageHero eyebrow="MATCH CENTRE" eyebrowBn="ম্যাচ সেন্টার" title={mode === "results" ? "RESULTS" : mode === "fixtures" ? "FIXTURES" : "MATCHES"} titleBn={mode === "results" ? "ফলাফল" : mode === "fixtures" ? "ফিক্সচার" : "ম্যাচ"} body="Every fixture, every result and every step of the journey." bodyBn="প্রতিটি ফিক্সচার, প্রতিটি ফলাফল এবং আমাদের পথচলার প্রতিটি ধাপ।" image={images.stadium}/><section className="section"><div className="site-container"><div className="match-tabs"><Link className={mode === "all" ? "active" : ""} href="/matches">{tr("OVERVIEW", "সংক্ষিপ্ত")}</Link><Link className={mode === "fixtures" ? "active" : ""} href="/fixtures">{tr("FIXTURES", "ফিক্সচার")}</Link><Link className={mode === "results" ? "active" : ""} href="/results">{tr("RESULTS", "ফলাফল")}</Link></div>{mode !== "results" && <><h3 className="list-heading">{tr("UPCOMING FIXTURES", "আসন্ন ফিক্সচার")}</h3><div className="fixture-list">{fixtures.map(f => <div className="fixture-card" key={f.date}><div className="fixture-date"><b>{f.date}</b><span>{f.month}</span></div><div className="fixture-competition"><small>{f.competition}</small><p><MapPin/> {f.venue}</p></div><div className="fixture-teams"><span><ClubMark alt="Club crest"/>{f.home}</span><b>{f.time}<small>VS</small></b><span><i>{f.away.slice(0,2)}</i>{f.away}</span></div><Button variant="outline" href="/contact">{tr("Details", "বিস্তারিত")}</Button></div>)}</div></>}{mode !== "fixtures" && <><h3 className="list-heading result-heading">{tr("LATEST RESULTS", "সর্বশেষ ফলাফল")}</h3><div className="fixture-list">{results.map(r => <div className="fixture-card result" key={r.date}><div className="fixture-date"><b>{r.date.split(" ")[0]}</b><span>{r.date.split(" ")[1]}</span></div><div className="fixture-competition"><small>{r.competition}</small><StatusPill status={r.state}/></div><div className="fixture-teams"><span><ClubMark alt="Club crest"/>{r.home}</span><b className="score">{r.homeScore}<small>—</small>{r.awayScore}</b><span><i>{r.away.slice(0,2)}</i>{r.away}</span></div><span className={r.homeScore > r.awayScore ? "result-badge win" : "result-badge draw"}>{r.homeScore > r.awayScore ? tr("WIN","জয়") : tr("DRAW","ড্র")}</span></div>)}</div></>}</div></section></>;
}

function TournamentPage({ register = false }: { register?: boolean }) {
  const { tr } = useI18n();
  if (register) return <TournamentForm/>;
  return <><PageHero eyebrow="COMPETE WITH US" eyebrowBn="আমাদের সঙ্গে প্রতিযোগিতা" title="TOURNAMENTS" titleBn="টুর্নামেন্ট" body="Where ambition meets community and champions are made." bodyBn="যেখানে উচ্চাকাঙ্ক্ষা ও সমাজ এক হয়, আর চ্যাম্পিয়নের জন্ম হয়।" image={images.hero}/><section className="section"><div className="site-container"><SectionTitle eyebrow="CURRENT COMPETITIONS" eyebrowBn="চলমান প্রতিযোগিতা" title="PLAY FOR THE MOMENT" titleBn="মুহূর্তের জন্য খেলুন"/><div className="tournament-grid"><div className="tournament-feature" style={{backgroundImage:`linear-gradient(0deg,rgba(2,17,12,.94),rgba(2,17,12,.15)),url(${images.action})`}}><span className="season-pill">2025 SEASON</span><div><small>KULANANDAPUR PREMIER LEAGUE</small><h3>KPL 2025</h3><p><CalendarDays/> 20 June — 25 July <MapPin/> Kulanandapur</p><Button href="/tournament/register">{tr("Register your team", "দল নিবন্ধন করুন")}</Button></div></div><div className="tournament-side"><div><span><Trophy/></span><div><small>{tr("REGISTRATION OPEN", "নিবন্ধন চলছে")}</small><h3>{tr("Fantastic Community Cup", "ফ্যান্টাস্টিক কমিউনিটি কাপ")}</h3><p>16 {tr("teams", "দল")} • 7-a-side • {tr("Open category", "উন্মুক্ত বিভাগ")}</p></div></div><div><span><Award/></span><div><small>{tr("COMING IN AUGUST", "আগস্টে আসছে")}</small><h3>{tr("Youth Football Festival", "যুব ফুটবল উৎসব")}</h3><p>U-16 • 12 {tr("teams", "দল")} • {tr("Development focus", "উন্নয়নমূলক")}</p></div></div></div></div></div></section><section className="section achievements"><div className="site-container"><SectionTitle eyebrow="HALL OF HONOUR" eyebrowBn="সম্মাননা" title="OUR ACHIEVEMENTS" titleBn="আমাদের অর্জন" center/><div className="honour-grid">{[["2024","KPL CHAMPIONS","কেপিএল চ্যাম্পিয়ন"],["2023","COMMUNITY CUP","কমিউনিটি কাপ"],["2022","DISTRICT RUNNERS-UP","জেলা রানার্সআপ"],["2019","FAIR PLAY AWARD","ফেয়ার প্লে পুরস্কার"]].map(x=><div key={x[0]}><Trophy/><strong>{x[0]}</strong><span>{tr(x[1],x[2])}</span></div>)}</div></div></section></>;
}

function TournamentForm() {
  const { tr } = useI18n(); const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null); const [loading,setLoading]=useState(false);
  async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setLoading(true);setMessage(null);const form=e.currentTarget;const data=Object.fromEntries(new FormData(form));try{const res=await fetch("/api/tournament-application",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});const json=await res.json() as {message:string};setMessage({type:res.ok?"success":"error",text:json.message});if(res.ok)form.reset();}catch{setMessage({type:"error",text:tr("Connection failed. Try again.","সংযোগ ব্যর্থ। আবার চেষ্টা করুন।")});}finally{setLoading(false)}}
  return <><PageHero eyebrow="KPL 2025" eyebrowBn="কেপিএল ২০২৫" title="REGISTER YOUR TEAM" titleBn="আপনার দল নিবন্ধন করুন" body="Submit your application. Our tournament team will contact you after review." bodyBn="আবেদন জমা দিন। যাচাই শেষে টুর্নামেন্ট দল যোগাযোগ করবে।" image={images.action}/><section className="section form-section"><div className="site-container narrow-grid"><div className="form-aside"><span><Trophy/></span><h2>{tr("YOUR ROAD TO GLORY STARTS HERE", "গৌরবের পথে যাত্রা এখানেই শুরু")}</h2><p>{tr("Applications remain pending until approved by the club administration.", "ক্লাব প্রশাসন অনুমোদন না করা পর্যন্ত আবেদন অপেক্ষমাণ থাকবে।")}</p><ul><li><Check/> {tr("Verified tournament management", "যাচাইকৃত টুর্নামেন্ট ব্যবস্থাপনা")}</li><li><Check/> {tr("Qualified referees", "যোগ্য রেফারি")}</li><li><Check/> {tr("Awards and media coverage", "পুরস্কার ও মিডিয়া কভারেজ")}</li></ul></div><form className="premium-form" onSubmit={submit}><div className="form-title"><small>TEAM APPLICATION</small><h2>{tr("Application details", "আবেদনের তথ্য")}</h2></div><div className="form-grid"><label>{tr("Team name","দলের নাম")}<input name="teamName" required/></label><label>{tr("Club name","ক্লাবের নাম")}<input name="clubName" required/></label><label>{tr("Manager name","ম্যানেজারের নাম")}<input name="managerName" required/></label><label>{tr("Mobile number","মোবাইল নম্বর")}<input name="mobile" type="tel" required/></label><label>{tr("Email address","ইমেইল ঠিকানা")}<input name="email" type="email" required/></label><label>{tr("Player count","খেলোয়াড় সংখ্যা")}<input name="playerCount" type="number" min="5" max="40" required/></label><label>{tr("Category","বিভাগ")}<select name="category" required><option value="">{tr("Select category","বিভাগ বাছুন")}</option><option>Open</option><option>Under 16</option><option>Seven-a-side</option></select></label><label className="full">{tr("Team address","দলের ঠিকানা")}<textarea name="address" required rows={4}/></label></div><FormMessage state={message}/><Button type="submit" disabled={loading}>{loading?tr("Submitting...","জমা হচ্ছে..."):tr("Submit application","আবেদন জমা দিন")}</Button></form></div></section></>;
}

type NewsPost={id:string;title:string;category:string;excerpt:string;body:string;coverImage:string|null;createdAt:string};
function useNews(){
  const [items,setItems]=useState<NewsPost[]>([]);const [loading,setLoading]=useState(true);
  useEffect(()=>{let cancelled=false;(async()=>{try{const res=await fetch("/api/news",{cache:"no-store"});const data=await res.json() as {posts?:NewsPost[]};if(!cancelled)setItems(data.posts||[])}catch{ /* best-effort */ }finally{if(!cancelled)setLoading(false)}})();return()=>{cancelled=true}},[]);
  return {items,loading};
}
function NewsGrid({limit=3,onSelect}:{limit?:number;onSelect?:(item:NewsPost)=>void}){const {tr}=useI18n();const {items,loading}=useNews();if(loading)return <div className="news-grid"/>;if(items.length===0)return <p style={{color:"var(--muted)"}}>{tr("No stories published yet.","এখনো কোনো সংবাদ প্রকাশিত হয়নি।")}</p>;return <div className="news-grid">{items.slice(0,limit).map((n,i)=><button className={`news-card ${i===0&&limit>3?"featured":""}`} key={n.id} onClick={()=>onSelect?.(n)}><div className="news-image">{n.coverImage&&<img src={n.coverImage} alt={n.title}/>}<span>{n.category}</span></div><div className="news-copy"><small>{new Date(n.createdAt).toLocaleDateString()}</small><h3>{n.title}</h3><p>{n.excerpt}</p><b>READ STORY <ArrowRight/></b></div></button>)}</div>}
function NewsPage(){const {tr}=useI18n();const [item,setItem]=useState<NewsPost|null>(null);return <><PageHero eyebrow="INSIDE THE CLUB" eyebrowBn="ক্লাবের ভেতর" title="LATEST NEWS" titleBn="সর্বশেষ সংবাদ" body="Stories, updates and moments from Fantastic FC." bodyBn="ফ্যান্টাস্টিক এফসির গল্প, আপডেট এবং মুহূর্ত।" image={images.rain}/><section className="section"><div className="site-container"><NewsGrid limit={30} onSelect={setItem}/></div></section><Modal open={!!item} onClose={()=>setItem(null)} wide>{item&&<article className="article-modal">{item.coverImage&&<img src={item.coverImage} alt={item.title}/>}<div><span>{item.category} • {new Date(item.createdAt).toLocaleDateString()}</span><h2>{item.title}</h2><p className="lead-copy">{item.excerpt}</p>{item.body&&<p>{item.body}</p>}</div></article>}</Modal></>}

function GalleryPage(){const {tr}=useI18n();const [view,setView]=useState<string|null>(null);return <><PageHero eyebrow="CLUB MOMENTS" eyebrowBn="ক্লাবের মুহূর্ত" title="GALLERY" titleBn="গ্যালারি" body="The moments, emotions and people behind the badge." bodyBn="ব্যাজের পেছনের মুহূর্ত, আবেগ এবং মানুষগুলো।" image={images.family}/><section className="section"><div className="site-container"><div className="gallery-filter"><button className="active">{tr("ALL MOMENTS","সব মুহূর্ত")}</button><button>{tr("MATCHDAY","ম্যাচডে")}</button><button>{tr("TRAINING","অনুশীলন")}</button><button>{tr("COMMUNITY","কমিউনিটি")}</button></div><div className="gallery-masonry">{gallery.map((g,i)=><button key={g} onClick={()=>setView(g)}><img src={g} alt={`Fantastic FC gallery ${i+1}`}/><span><Play/> {tr("View moment","মুহূর্ত দেখুন")}</span></button>)}</div></div></section><Modal open={!!view} onClose={()=>setView(null)} wide>{view&&<img className="lightbox-image" src={view} alt="Fantastic FC moment"/>}</Modal></>}

function ContactPage(){const {tr}=useI18n();const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null);const [loading,setLoading]=useState(false);async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setLoading(true);const form=e.currentTarget;try{const res=await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(form)))});const data=await res.json() as {message:string};setMessage({type:res.ok?"success":"error",text:data.message});if(res.ok){form.reset()}}catch{setMessage({type:"error",text:tr("Unable to connect.","সংযোগ করা যাচ্ছে না।")})}finally{setLoading(false)}}return <><PageHero eyebrow="GET IN TOUCH" eyebrowBn="যোগাযোগ করুন" title="CONTACT US" titleBn="আমাদের সঙ্গে যোগাযোগ" body="Questions, opportunities or match enquiries—we are ready to listen." bodyBn="প্রশ্ন, সুযোগ বা ম্যাচ সংক্রান্ত বিষয়ে—আমরা আপনার কথা শুনতে প্রস্তুত।" image={images.stadium}/><section className="section"><div className="site-container contact-grid"><div><SectionTitle eyebrow="CLUB INFORMATION" eyebrowBn="ক্লাবের তথ্য" title="COME SAY HELLO" titleBn="আমাদের সঙ্গে দেখা করুন"/><div className="contact-cards"><div><MapPin/><span><b>{tr("Club address","ক্লাবের ঠিকানা")}</b>{tr("Kulanandapur School Field, Kushtia, Bangladesh","কুলানন্দপুর স্কুল মাঠ, কুষ্টিয়া, বাংলাদেশ")}</span></div><div><Phone/><span><b>{tr("Call the club","ক্লাবে কল করুন")}</b>+880 1712-000000</span></div><div><Mail/><span><b>{tr("Email us","ইমেইল করুন")}</b>hello@fantasticfc.com</span></div><div><MessageCircle/><span><b>{tr("Office hours","অফিস সময়")}</b>{tr("Saturday–Thursday • 3:00–8:00 PM","শনিবার–বৃহস্পতিবার • বিকাল ৩টা–রাত ৮টা")}</span></div></div></div><form className="premium-form" onSubmit={submit}><div className="form-title"><small>SEND A MESSAGE</small><h2>{tr("How can we help?","আমরা কীভাবে সাহায্য করতে পারি?")}</h2></div><div className="form-grid"><label>{tr("Your name","আপনার নাম")}<input name="name" required/></label><label>{tr("Mobile","মোবাইল")}<input name="mobile"/></label><label className="full">{tr("Email","ইমেইল")}<input name="email" type="email" required/></label><label className="full">{tr("Subject","বিষয়")}<input name="subject" required/></label><label className="full">{tr("Message","বার্তা")}<textarea name="message" rows={5} minLength={10} required/></label></div><FormMessage state={message}/><Button type="submit" disabled={loading}>{loading?tr("Sending...","পাঠানো হচ্ছে..."):tr("Send message","বার্তা পাঠান")}</Button></form></div></section></>}

function SecureRecoveryPage({ type }: { type: "forgot" | "forgot-pin" }) {
  const { tr } = useI18n();
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true); setMessage(null);
    const identifier = String(new FormData(event.currentTarget).get("identifier") || "");
    if (type === "forgot") {
      setMessage({ type: "success", text: tr("Your secure password reset request has been sent to the admin.", "আপনার নিরাপদ পাসওয়ার্ড রিসেট অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।") });
      setLoading(false); return;
    }
    try {
      const response = await fetch("/api/pin-reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ identifier }) });
      const data = await response.json() as { message: string };
      setMessage({ type: response.ok ? "success" : "error", text: data.message });
      if (response.ok) event.currentTarget.reset();
    } catch {
      setMessage({ type: "error", text: tr("Unable to submit the request. Try again.", "অনুরোধ পাঠানো যায়নি। আবার চেষ্টা করুন।") });
    } finally { setLoading(false); }
  }
  return <div className="auth-shell simple"><div className="auth-form-wrap"><ClubLogo/><form className="auth-form" onSubmit={submit}><small>SECURE RECOVERY</small><h2>{tr(type==="forgot-pin"?"Reset member PIN":"Forgot your password?",type==="forgot-pin"?"সদস্য পিন রিসেট":"পাসওয়ার্ড ভুলে গেছেন?")}</h2><p>{tr("Enter your registered mobile, email or member ID. The admin can review your complete request and send a new PIN to your registered email.","নিবন্ধিত মোবাইল, ইমেইল বা সদস্য আইডি দিন। অ্যাডমিন সম্পূর্ণ অনুরোধ যাচাই করে নিবন্ধিত ইমেইলে নতুন পিন পাঠাতে পারবেন।")}</p><label>{tr("Mobile / Email / Member ID","মোবাইল / ইমেইল / সদস্য আইডি")}<input name="identifier" required autoComplete="username"/></label><FormMessage state={message}/><Button type="submit" disabled={loading}>{loading?tr("Sending request...","অনুরোধ পাঠানো হচ্ছে..."):tr("Request secure reset","নিরাপদ রিসেট অনুরোধ")}</Button><p className="auth-link"><Link href="/login">← {tr("Back to sign in","লগইনে ফিরুন")}</Link></p></form></div></div>;
}

function AuthPage({type}:{type:"login"|"register"|"forgot"|"forgot-pin"}){const {tr}=useI18n();const {branding}=useBranding();const [role,setRole]=useState<"player"|"admin">("player");const [message,setMessage]=useState<{type:"success"|"error";text:string}|null>(null);const [loading,setLoading]=useState(false);useEffect(()=>{const requested=new URLSearchParams(window.location.search).get("role");if(requested==="admin"||requested==="player")setRole(requested)},[]);const [photoPreview,setPhotoPreview]=useState<string|null>(null);const [photoError,setPhotoError]=useState<string|null>(null);
  function onPhotoChange(event:ChangeEvent<HTMLInputElement>){const file=event.target.files?.[0];setPhotoError(null);if(!file)return;if(!file.type.match(/^image\/(png|jpeg|webp|gif)$/)||file.size>1_500_000){setPhotoError(tr("Use a PNG, JPG, WebP or GIF photo under 1.5 MB.","১.৫ এমবির কম PNG, JPG, WebP বা GIF ছবি ব্যবহার করুন।"));event.target.value="";return}const reader=new FileReader();reader.onload=()=>setPhotoPreview(String(reader.result||""));reader.readAsDataURL(file)}
  async function register(e:FormEvent<HTMLFormElement>){e.preventDefault();setLoading(true);const form=e.currentTarget;try{const payload:Record<string,unknown>=Object.fromEntries(new FormData(form));payload.profilePhoto=photoPreview;const res=await fetch("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const data=await res.json() as {message:string;memberId?:string};setMessage({type:res.ok?"success":"error",text:res.ok?`${data.message} ${data.memberId??""}`:data.message});if(res.ok)form.reset()}catch{setMessage({type:"error",text:tr("Unable to connect.","সংযোগ করা যাচ্ছে না।")})}finally{setLoading(false)}}
  async function adminLogin(e:FormEvent<HTMLFormElement>){e.preventDefault();setLoading(true);setMessage(null);const data=new FormData(e.currentTarget);try{const res=await fetch("/api/admin/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:String(data.get("email")||"").trim(),pin:String(data.get("pin")||"")})});const result=await res.json() as {message:string};if(res.ok){const next=new URLSearchParams(window.location.search).get("next")||"/admin";window.location.href=next}else{setMessage({type:"error",text:result.message});setLoading(false)}}catch{setMessage({type:"error",text:tr("Unable to connect.","সংযোগ করা যাচ্ছে না।")});setLoading(false)}}
  async function memberLogin(e:FormEvent<HTMLFormElement>){e.preventDefault();setLoading(true);setMessage(null);const data=new FormData(e.currentTarget);try{const res=await fetch("/api/member/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({identifier:String(data.get("identifier")||"").trim(),password:String(data.get("password")||"")})});const result=await res.json() as {message:string};if(res.ok){const next=new URLSearchParams(window.location.search).get("next")||"/member";window.location.href=next}else{setMessage({type:"error",text:result.message});setLoading(false)}}catch{setMessage({type:"error",text:tr("Unable to connect.","সংযোগ করা যাচ্ছে না।")});setLoading(false)}}
  if(type==="register")return <div className="auth-shell"><div className="auth-visual" style={{backgroundImage:`linear-gradient(0deg,rgba(1,17,11,.9),rgba(1,17,11,.3)),url(${images.action})`}}><ClubLogo inverse/><div><span>BE PART OF SOMETHING</span><h1>{tr("JOIN THE FANTASTIC FAMILY", "ফ্যান্টাস্টিক পরিবারে যোগ দিন")}</h1><p>{tr("Your journey begins with one application.","একটি আবেদনের মাধ্যমে আপনার যাত্রা শুরু।")}</p></div></div><div className="auth-form-wrap"><div className="auth-mobile-logo"><ClubLogo/></div><form className="auth-form register" onSubmit={register}><small>{tr("MEMBER REGISTRATION","সদস্য নিবন্ধন")}</small><h2>{tr("Create your application","আপনার আবেদন তৈরি করুন")}</h2><p>{tr("Your account will remain pending until admin approval.","অ্যাডমিন অনুমোদন না করা পর্যন্ত অ্যাকাউন্ট অপেক্ষমাণ থাকবে।")}</p><div className="form-grid"><label>{tr("Full name","পূর্ণ নাম")}<input name="fullName" required/></label><label>{tr("Mobile","মোবাইল")}<input name="mobile" required/></label><label>{tr("Email","ইমেইল")}<input name="email" type="email" required/></label><label>{tr("Date of birth","জন্মতারিখ")}<input name="dateOfBirth" type="date"/></label><label>{tr("Emergency contact","জরুরি যোগাযোগ")}<input name="emergencyContact"/></label><label>{tr("Jersey number","জার্সি নম্বর")}<input name="jerseyNumber" type="number" min="1" max="99"/></label><label>{tr("Position","পজিশন")}<select name="position"><option value="">{tr("Select","বাছুন")}</option><option value="GOALKEEPER">Goalkeeper</option><option value="DEFENDER">Defender</option><option value="MIDFIELDER">Midfielder</option><option value="FORWARD">Forward</option></select></label><label>{tr("Joining date","যোগদানের তারিখ")}<input name="joiningDate" type="date"/></label><label className="full">{tr("Address","ঠিকানা")}<textarea name="address" rows={2}/></label><label>{tr("Password","পাসওয়ার্ড")}<input name="password" type="password" minLength={8} required/></label><label>{tr("Confirm password","পাসওয়ার্ড নিশ্চিত করুন")}<input name="confirmPassword" type="password" minLength={8} required/></label></div><label className="upload-field photo-upload">{photoPreview?<img src={photoPreview} alt="Profile preview" className="photo-upload-preview"/>:<Upload/>}<span>{photoPreview?tr("Change profile photo","প্রোফাইল ছবি পরিবর্তন"):tr("Upload a profile photo (optional)","প্রোফাইল ছবি আপলোড করুন (ঐচ্ছিক)")}</span><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={onPhotoChange}/></label>{photoError&&<p className="upload-error">{photoError}</p>}<FormMessage state={message}/><Button type="submit" disabled={loading}>{loading?tr("Submitting...","জমা হচ্ছে..."):tr("Submit registration","নিবন্ধন জমা দিন")}</Button><p className="auth-link">{tr("Already a member?","ইতিমধ্যে সদস্য?")} <Link href="/login">{tr("Sign in","লগইন")}</Link></p></form></div></div>;
  if(type==="forgot"||type==="forgot-pin")return <SecureRecoveryPage type={type}/>;
  return <div className="auth-shell"><div className="auth-visual" style={{backgroundImage:`linear-gradient(0deg,rgba(1,17,11,.92),rgba(1,17,11,.28)),url(${images.stadium})`}}><ClubLogo inverse/><div><span>WELCOME BACK</span><h1>{tr("YOUR CLUB. YOUR FAMILY.","আপনার ক্লাব। আপনার পরিবার।")}</h1><p>{tr("Enter the secure portal and stay connected.","নিরাপদ পোর্টালে প্রবেশ করুন এবং সংযুক্ত থাকুন।")}</p></div></div><div className="auth-form-wrap"><form className={`auth-form login-form ${role}`} onSubmit={role==="admin"?adminLogin:memberLogin}><small>{role==="admin"?tr("ADMIN PANEL ACCESS","অ্যাডমিন প্যানেল প্রবেশ"):tr("PLAYER PORTAL ACCESS","খেলোয়াড় পোর্টাল প্রবেশ")}</small><h2>{role==="admin"?tr("Sign in as administrator","অ্যাডমিন হিসেবে লগইন করুন"):tr("Sign in to player portal","খেলোয়াড় পোর্টালে লগইন করুন")}</h2><p className="login-intro">{role==="admin"?tr("Authorized Admin and Super Admin accounts only.","শুধু অনুমোদিত অ্যাডমিন ও সুপার অ্যাডমিন অ্যাকাউন্টের জন্য।"):tr("Approved players and active club members can access the portal.","অনুমোদিত খেলোয়াড় ও সক্রিয় ক্লাব সদস্যরা পোর্টাল ব্যবহার করতে পারবেন।")}</p><div className="role-switch access-role-switch"><button type="button" className={role==="player"?"active":""} onClick={()=>setRole("player")}><span><UserRound/></span><div><b>{tr("Player / Member","খেলোয়াড় / সদস্য")}</b><small>{branding.portalName}</small></div></button><button type="button" className={role==="admin"?"active admin":""} onClick={()=>setRole("admin")}><span><ShieldCheck/></span><div><b>{tr("Admin Panel","অ্যাডমিন প্যানেল")}</b><small>{branding.adminName}</small></div></button></div><div className={`login-security-note ${role}`}><span>{role==="admin"?<LockKeyhole/>:<UserRound/>}</span><div><b>{role==="admin"?tr("Protected administration area","সুরক্ষিত প্রশাসনিক এলাকা"):tr("Approved account required","অনুমোদিত অ্যাকাউন্ট প্রয়োজন")}</b><small>{role==="admin"?tr("All sign-in activity is monitored.","সব লগইন কার্যক্রম পর্যবেক্ষণ করা হয়।"):tr("Pending or blacklisted accounts cannot sign in.","অপেক্ষমাণ বা কালো তালিকাভুক্ত অ্যাকাউন্ট লগইন করতে পারবে না।")}</small></div></div><label>{role==="admin"?tr("Admin email","অ্যাডমিন ইমেইল"):tr("Mobile / Email / Member ID","মোবাইল / ইমেইল / সদস্য আইডি")}<input name={role==="admin"?"email":"identifier"} type={role==="admin"?"email":"text"} required autoComplete="username" placeholder={role==="admin"?"admin@fantasticfc.com":"FFC-0012"}/></label><label>{role==="admin"?tr("Admin PIN","অ্যাডমিন পিন"):tr("Password / PIN","পাসওয়ার্ড / পিন")}<input name={role==="admin"?"pin":"password"} type="password" required autoComplete="current-password" placeholder="••••••••"/></label><div className="form-options"><label><input type="checkbox"/> {tr("Remember me","মনে রাখুন")}</label><Link href={role==="admin"?"/forgot?role=admin":"/forgot"}>{tr("Forgot password?","পাসওয়ার্ড ভুলে গেছেন?")}</Link></div><FormMessage state={message}/><Button type="submit" disabled={loading}>{loading?tr("Signing in...","লগইন হচ্ছে..."):role==="admin"?tr("Enter admin panel","অ্যাডমিন প্যানেলে প্রবেশ"):tr("Enter player portal","খেলোয়াড় পোর্টালে প্রবেশ")}</Button>{role==="player"&&<Link className="pin-link" href="/forgot-pin">{tr("Request a PIN reset","পিন রিসেট অনুরোধ")}</Link>}<p className="auth-link">{tr("Not a member yet?","এখনও সদস্য নন?")} <Link href="/register">{tr("Apply now","এখনই আবেদন")}</Link></p></form></div></div>;
}

export function PublicSite(){const pathname=usePathname();let content;if(pathname==="/")content=<HomePage/>;else if(pathname==="/about"||pathname==="/team")content=<AboutPage/>;else if(pathname==="/players")content=<PlayersPage/>;else if(pathname==="/matches")content=<MatchesPage mode="all"/>;else if(pathname==="/fixtures")content=<MatchesPage mode="fixtures"/>;else if(pathname==="/results")content=<MatchesPage mode="results"/>;else if(pathname==="/tournaments")content=<TournamentPage/>;else if(pathname==="/tournament/register")content=<TournamentPage register/>;else if(pathname==="/news")content=<NewsPage/>;else if(pathname==="/gallery")content=<GalleryPage/>;else if(pathname==="/contact")content=<ContactPage/>;else if(pathname==="/register")content=<AuthPage type="register"/>;else if(pathname==="/forgot")content=<AuthPage type="forgot"/>;else if(pathname==="/forgot-pin")content=<AuthPage type="forgot-pin"/>;else content=<AuthPage type="login"/>;const auth=["/login","/register","/forgot","/forgot-pin"].includes(pathname);return <div className="public-site">{!auth&&<PublicHeader/>}<main>{content}</main>{!auth&&<PublicFooter/>}</div>}
