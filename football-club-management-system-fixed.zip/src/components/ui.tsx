"use client";

import Link from "next/link";
import {
  ArrowUpRight,
  CheckCircle2,
  ChevronRight,
  Languages,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, type ButtonHTMLAttributes, type ReactNode } from "react";
import { useI18n } from "@/lib/i18n";
import { useBranding } from "@/lib/branding";

export function ClubMark({ className = "", alt }: { className?: string; alt?: string }) {
  const { branding } = useBranding();
  return <img className={className} src={branding.logo} alt={alt || `${branding.shortName} crest`} />;
}

export function ClubLogo({ compact = false, inverse = false }: { compact?: boolean; inverse?: boolean }) {
  const { branding } = useBranding();
  return (
    <Link href="/" className="club-logo" aria-label={`${branding.siteName} home`}>
      <ClubMark />
      {!compact && (
        <span className={inverse ? "logo-copy inverse" : "logo-copy"}>
          <b>{branding.siteName}</b>
          <strong>{branding.shortName}</strong>
          <small>{branding.tagline}</small>
        </span>
      )}
    </Link>
  );
}

export function PaymentLogo({ name, compact = false }: { name: string; compact?: boolean }) {
  const slug = name.toLowerCase().replace(/\s+/g, "");
  const supported: Record<string, string> = { bkash: "bkash", nagad: "nagad", upay: "upay", rocket: "rocket", cash: "cash", visa: "cash" };
  const file = supported[slug];
  if (file) return <img className={compact ? "payment-brand-logo compact" : "payment-brand-logo"} src={`/payments/${file}.png`} alt={`${name} logo`} />;
  return <span className={compact ? "payment-brand-fallback compact" : "payment-brand-fallback"}>{name.slice(0, 2).toUpperCase()}</span>;
}

export function LanguageSwitcher({ dark = false }: { dark?: boolean }) {
  const { language, setLanguage } = useI18n();
  return (
    <div className={dark ? "language-switch dark" : "language-switch"}>
      <Languages size={15} />
      <button className={language === "bn" ? "active" : ""} onClick={() => setLanguage("bn")}>বাংলা</button>
      <span>/</span>
      <button className={language === "en" ? "active" : ""} onClick={() => setLanguage("en")}>EN</button>
    </div>
  );
}

export function Button({
  children,
  variant = "primary",
  href,
  icon = true,
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  variant?: "primary" | "dark" | "ghost" | "outline" | "danger";
  href?: string;
  icon?: boolean;
}) {
  const classes = `btn btn-${variant} ${className}`;
  if (href) {
    return <Link className={classes} href={href}>{children}{icon && <ArrowUpRight size={17} />}</Link>;
  }
  return <button className={classes} {...props}>{children}{icon && <ArrowUpRight size={17} />}</button>;
}

export function SectionTitle({
  eyebrow,
  eyebrowBn,
  title,
  titleBn,
  body,
  bodyBn,
  center = false,
  action,
}: {
  eyebrow: string;
  eyebrowBn: string;
  title: string;
  titleBn: string;
  body?: string;
  bodyBn?: string;
  center?: boolean;
  action?: ReactNode;
}) {
  const { tr } = useI18n();
  return (
    <div className={`section-title-row ${center ? "center" : ""}`}>
      <div className="section-title">
        <div className="eyebrow"><span />{tr(eyebrow, eyebrowBn)}</div>
        <h2>{tr(title, titleBn)}</h2>
        {body && <p>{tr(body, bodyBn || body)}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

export function PageHero({
  eyebrow,
  eyebrowBn,
  title,
  titleBn,
  body,
  bodyBn,
  image,
}: {
  eyebrow: string;
  eyebrowBn: string;
  title: string;
  titleBn: string;
  body: string;
  bodyBn: string;
  image: string;
}) {
  const { tr } = useI18n();
  return (
    <section className="page-hero" style={{ backgroundImage: `linear-gradient(90deg,rgba(3,18,13,.94),rgba(3,18,13,.42)),url(${image})` }}>
      <div className="site-container page-hero-inner">
        <div className="eyebrow light"><span />{tr(eyebrow, eyebrowBn)}</div>
        <h1>{tr(title, titleBn)}</h1>
        <p>{tr(body, bodyBn)}</p>
        <div className="breadcrumb"><Link href="/">{tr("Home", "হোম")}</Link><ChevronRight size={14}/><b>{tr(title, titleBn)}</b></div>
      </div>
    </section>
  );
}

export function StatusPill({ status }: { status: string }) {
  return <span className={`status-pill ${status.toLowerCase().replaceAll(" ", "-")}`}><i />{status}</span>;
}

export function StatCard({
  icon: Icon,
  label,
  value,
  change,
  href,
  tone = "green",
}: {
  icon: LucideIcon;
  label: string;
  value: string;
  change?: string;
  href?: string;
  tone?: "green" | "blue" | "orange" | "violet" | "red";
}) {
  const content = (
    <>
      <span className={`stat-icon ${tone}`}><Icon size={22} /></span>
      <div><p>{label}</p><strong>{value}</strong>{change && <small>{change}</small>}</div>
      {href && <ChevronRight className="stat-arrow" size={18}/>} 
    </>
  );
  return href ? <Link className="stat-card" href={href}>{content}</Link> : <div className="stat-card">{content}</div>;
}

export function Modal({ open, onClose, children, wide = false }: { open: boolean; onClose: () => void; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const close = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", close);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", close); document.body.style.overflow = ""; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal-card ${wide ? "wide" : ""}`} role="dialog" aria-modal="true">
        <button className="modal-close" onClick={onClose} aria-label="Close"><X size={20}/></button>
        {children}
      </div>
    </div>
  );
}

export function FormMessage({ state }: { state: { type: "success" | "error"; text: string } | null }) {
  if (!state) return null;
  return <div className={`form-message ${state.type}`}>{state.type === "success" && <CheckCircle2 size={17}/>} {state.text}</div>;
}

export function Avatar({ src, name, size = "md" }: { src?: string; name: string; size?: "sm" | "md" | "lg" }) {
  return src ? <img className={`avatar ${size}`} src={src} alt={name} /> : <span className={`avatar fallback ${size}`}>{name.split(" ").map(x => x[0]).slice(0,2).join("")}</span>;
}

export function Panel({ children, title, action, className = "" }: { children: ReactNode; title?: string; action?: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>{title && <div className="panel-head"><h3>{title}</h3>{action}</div>}{children}</section>;
}
