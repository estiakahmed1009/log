import { db } from "@/db";
import { members } from "@/db/schema";
import { eq } from "drizzle-orm";
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { NextResponse } from "next/server";

const scrypt = promisify(scryptCallback);

async function verifyPassword(stored: string, input: string): Promise<boolean> {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const derived = (await scrypt(input, salt, 64)) as Buffer;
  return timingSafeEqual(Buffer.from(hash, "hex"), derived);
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const memberCode = String(body.memberCode || "").trim();
    const currentPassword = String(body.currentPassword || "");
    const newPassword = String(body.newPassword || "");
    const confirmPassword = String(body.confirmPassword || "");

    if (!memberCode || !currentPassword || newPassword.length < 8) {
      return NextResponse.json({ message: "New password must be at least 8 characters." }, { status: 400 });
    }
    if (newPassword !== confirmPassword) {
      return NextResponse.json({ message: "New passwords do not match." }, { status: 400 });
    }

    const [member] = await db.select({ id: members.id, passwordHash: members.passwordHash }).from(members).where(eq(members.memberId, memberCode)).limit(1);
    if (!member) return NextResponse.json({ message: "Account not found." }, { status: 404 });

    const valid = await verifyPassword(member.passwordHash, currentPassword);
    if (!valid) return NextResponse.json({ message: "Current password is incorrect." }, { status: 403 });

    const salt = randomBytes(16).toString("hex");
    const derived = (await scrypt(newPassword, salt, 64)) as Buffer;
    const passwordHash = `${salt}:${derived.toString("hex")}`;
    await db.update(members).set({ passwordHash, updatedAt: new Date() }).where(eq(members.id, member.id));

    return NextResponse.json({ message: "Password changed successfully." });
  } catch (error) {
    console.error("Password change failed", error);
    return NextResponse.json({ message: "Unable to change password." }, { status: 500 });
  }
}
