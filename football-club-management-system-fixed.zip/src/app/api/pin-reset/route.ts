import { db } from "@/db";
import { auditLogs, members, pinResetRequests } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { randomInt } from "node:crypto";
import { NextResponse } from "next/server";
import { hashSecret } from "@/lib/hash";

const genericMessage = "If the account is approved, a new PIN has been emailed to the registered address.";

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[character] || character);
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { identifier?: unknown };
    const identifier = typeof body.identifier === "string" ? body.identifier.trim().slice(0, 180) : "";
    if (identifier.length < 4) {
      return NextResponse.json({ message: "Enter a valid mobile, email or member ID." }, { status: 400 });
    }

    const [member] = await db
      .select()
      .from(members)
      .where(or(eq(members.memberId, identifier), eq(members.email, identifier.toLowerCase()), eq(members.mobile, identifier)))
      .limit(1);

    // Always return the same generic message whether or not the account exists,
    // so this endpoint can't be used to check which mobiles/emails are registered.
    if (!member || member.status !== "ACTIVE") {
      return NextResponse.json({ message: genericMessage }, { status: 202 });
    }

    // Generate a fresh one-time PIN and store it right away — no manual admin click needed.
    const pin = String(randomInt(100000, 1000000));
    const pinHash = await hashSecret(pin);
    await db.update(members).set({ pinHash, updatedAt: new Date() }).where(eq(members.id, member.id));

    let emailStatus = "FAILED";
    let providerId: string | null = null;
    const resendKey = process.env.RESEND_API_KEY;
    const from = process.env.ADMIN_EMAIL_FROM || "Fantastic FC Admin <onboarding@resend.dev>";

    if (resendKey) {
      try {
        const response = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            from,
            to: [member.email],
            subject: "Your new Fantastic FC Portal PIN",
            html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">FANTASTIC FC PORTAL</h2><p>Hello ${escapeHtml(member.fullName)},</p><p>A PIN reset was requested for your account. Your new PIN is below.</p><div style="font-size:34px;letter-spacing:8px;font-weight:800;background:#eef6ef;padding:20px;text-align:center;color:#0d3a28">${pin}</div><p>Member ID: <strong>${escapeHtml(member.memberId)}</strong></p><p>Please sign in and keep this PIN private. If you did not request this reset, contact the club admin immediately.</p></div>`,
          }),
        });
        const result = (await response.json().catch(() => ({}))) as { id?: string };
        if (response.ok) {
          emailStatus = "SENT";
          providerId = result.id || null;
        }
      } catch (mailError) {
        console.error("PIN reset email dispatch failed", mailError);
      }
    }

    // Keep a record for the admin's PIN reset history / audit trail.
    await db.insert(pinResetRequests).values({
      memberId: member.id,
      memberCode: member.memberId,
      requesterName: member.fullName,
      email: member.email,
      mobile: member.mobile,
      status: "APPROVED",
      emailStatus,
      emailProviderId: providerId,
      resolvedAt: new Date(),
    });
    await db.insert(auditLogs).values({
      actor: "Automated PIN reset", action: "Member PIN auto-reset and emailed", entityType: "PIN_RESET", entityId: member.id,
      details: { memberCode: member.memberId, email: member.email, emailStatus },
    });

    return NextResponse.json({ message: genericMessage }, { status: 202 });
  } catch (error) {
    console.error("PIN reset request failed", error);
    return NextResponse.json({ message: "Unable to submit the reset request right now." }, { status: 500 });
  }
}
