import { db } from "@/db";
import { paymentMethods } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

const DEFAULTS = [
  { name: "bKash", accountNumber: "017•••••427", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 1 },
  { name: "Nagad", accountNumber: "018•••••965", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 2 },
  { name: "Upay", accountNumber: "016•••••582", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 3 },
  { name: "Rocket", accountNumber: "019•••••318", accountName: "Fantastic FC", instructions: "Send Money and enter the exact transaction ID.", warning: "Never share your portal PIN.", enabled: true, displayOrder: 4 },
  { name: "Cash", accountNumber: "CASH-DESK", accountName: "Fantastic FC", instructions: "Pay at the club desk and keep your receipt.", warning: "Ask for a signed receipt.", enabled: true, displayOrder: 5 },
];

async function ensureSeeded() {
  const existing = await db.select({ id: paymentMethods.id }).from(paymentMethods).limit(1);
  if (existing.length === 0) {
    await db.insert(paymentMethods).values(DEFAULTS);
  }
}

export async function GET() {
  try {
    await ensureSeeded();
    const rows = await db.select().from(paymentMethods).where(eq(paymentMethods.enabled, true)).orderBy(asc(paymentMethods.displayOrder));
    return NextResponse.json({ methods: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load payment methods", error);
    return NextResponse.json({ methods: [] });
  }
}
