import { db } from "@/db";
import { auditLogs, matches } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";

function validLogo(value: string): boolean {
  if (!value) return true; // optional
  return /^data:image\/(png|jpeg|jpg|webp);base64,/.test(value) && value.length < 2_100_000;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(matches).orderBy(desc(matches.matchDatetime));
    return NextResponse.json({ matches: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load matches", error);
    return NextResponse.json({ matches: [] });
  }
}

export async function POST(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const opponentName = clean(body.opponentName, 120);
    const opponentLogoUrl = clean(body.opponentLogoUrl, 2_100_000);
    const dateStr = clean(body.matchDate, 20);
    const timeStr = clean(body.matchTime, 20);
    if (!opponentName) return NextResponse.json({ message: "Enter the opponent club name." }, { status: 400 });
    if (!dateStr || !timeStr) return NextResponse.json({ message: "Enter the match date and time." }, { status: 400 });
    if (!validLogo(opponentLogoUrl)) return NextResponse.json({ message: "Use a PNG, JPG or WebP logo under ~1.5 MB." }, { status: 400 });
    const matchDatetime = new Date(`${dateStr}T${timeStr}`);
    if (Number.isNaN(matchDatetime.getTime())) return NextResponse.json({ message: "Invalid match date or time." }, { status: 400 });

    const [created] = await db.insert(matches).values({
      opponentName,
      opponentLogoUrl: opponentLogoUrl || null,
      matchDatetime,
      competition: clean(body.competition, 120) || null,
      groupName: clean(body.groupName, 60) || null,
      venue: clean(body.venue, 160) || null,
      matchType: clean(body.matchType, 40) || "LEAGUE",
      homeAway: clean(body.homeAway, 10) || "HOME",
      status: clean(body.status, 20) || "UPCOMING",
    }).returning({ id: matches.id });

    await db.insert(auditLogs).values({ actor: "Club admin", action: "Match created", entityType: "MATCH", entityId: created.id, details: { opponentName } });
    return NextResponse.json({ message: "Match saved.", id: created.id }, { status: 201 });
  } catch (error) {
    console.error("Unable to create match", error);
    return NextResponse.json({ message: "Unable to save match." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = clean(body.id, 60);
    if (!id) return NextResponse.json({ message: "Missing match id." }, { status: 400 });

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof body.opponentName === "string") updates.opponentName = clean(body.opponentName, 120);
    if (typeof body.opponentLogoUrl === "string") {
      const logo = clean(body.opponentLogoUrl, 2_100_000);
      if (!validLogo(logo)) return NextResponse.json({ message: "Use a PNG, JPG or WebP logo under ~1.5 MB." }, { status: 400 });
      updates.opponentLogoUrl = logo || null;
    }
    if (typeof body.matchDate === "string" && typeof body.matchTime === "string" && body.matchDate && body.matchTime) {
      const matchDatetime = new Date(`${body.matchDate}T${body.matchTime}`);
      if (Number.isNaN(matchDatetime.getTime())) return NextResponse.json({ message: "Invalid match date or time." }, { status: 400 });
      updates.matchDatetime = matchDatetime;
    }
    if (typeof body.competition === "string") updates.competition = clean(body.competition, 120) || null;
    if (typeof body.groupName === "string") updates.groupName = clean(body.groupName, 60) || null;
    if (typeof body.venue === "string") updates.venue = clean(body.venue, 160) || null;
    if (typeof body.matchType === "string") updates.matchType = clean(body.matchType, 40);
    if (typeof body.homeAway === "string") updates.homeAway = clean(body.homeAway, 10);
    if (typeof body.status === "string") updates.status = clean(body.status, 20);
    if (typeof body.homeScore === "number") updates.homeScore = body.homeScore;
    if (typeof body.awayScore === "number") updates.awayScore = body.awayScore;

    await db.update(matches).set(updates).where(eq(matches.id, id));
    await db.insert(auditLogs).values({ actor: "Club admin", action: "Match updated", entityType: "MATCH", entityId: id, details: { fields: Object.keys(updates) } });
    return NextResponse.json({ message: "Match updated." });
  } catch (error) {
    console.error("Unable to update match", error);
    return NextResponse.json({ message: "Unable to update match." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing match id." }, { status: 400 });
    await db.delete(matches).where(eq(matches.id, id));
    await db.insert(auditLogs).values({ actor: "Club admin", action: "Match deleted", entityType: "MATCH", entityId: id, details: {} });
    return NextResponse.json({ message: "Match deleted." });
  } catch (error) {
    console.error("Unable to delete match", error);
    return NextResponse.json({ message: "Unable to delete match." }, { status: 500 });
  }
}
