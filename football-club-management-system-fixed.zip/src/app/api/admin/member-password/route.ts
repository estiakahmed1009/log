import { db } from "@/db";
import { members } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

export async function POST(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as { memberId?: unknown };
    const memberId = typeof body.memberId === "string" ? body.memberId : "";
    if (!memberId) return NextResponse.json({ message: "Member ID is required." }, { status: 400 });

    const [member] = await db.select({ passwordHash: members.passwordHash, fullName: members.fullName, memberId: members.memberId }).from(members).where(eq(members.memberId, memberId)).limit(1);
    if (!member) return NextResponse.json({ message: "Member account not found." }, { status: 404 });

    // Password is stored as scrypt hash (salt:hash). Admin can see the hash format.
    // For admin convenience, show the stored hash indicator. Raw passwords cannot be recovered from scrypt.
    const [salt] = member.passwordHash.split(":");
    const isSeeded = salt === "seed";
    
    return NextResponse.json({
      memberId: member.memberId,
      memberName: member.fullName,
      passwordNote: isSeeded
        ? "This is a seeded demo account. Password was set during database initialization."
        : "Password is securely hashed with scrypt. The original text cannot be recovered. Use PIN Reset to generate a new credential.",
      hashPreview: `${member.passwordHash.slice(0, 20)}...${member.passwordHash.slice(-8)}`,
      canRecover: false,
    });
  } catch (error) {
    console.error("Password view failed", error);
    return NextResponse.json({ message: "Unable to retrieve password information." }, { status: 500 });
  }
}
