import { db } from "@/db";
import { auditLogs, financeEntries, members, payments } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select({
      id: financeEntries.id, title: financeEntries.title, category: financeEntries.category,
      income: financeEntries.income, expense: financeEntries.expense, method: financeEntries.method,
      note: financeEntries.note, createdAt: financeEntries.createdAt,
      memberId: financeEntries.memberId, memberName: members.fullName, memberPhoto: members.profilePhoto, memberJersey: members.jerseyNumber,
    }).from(financeEntries).leftJoin(members, eq(financeEntries.memberId, members.id)).orderBy(desc(financeEntries.createdAt));

    // Total unpaid: real pending member-fee submissions awaiting verification, not a made-up figure.
    const pendingDues = await db.select({ amount: payments.amount }).from(payments).where(eq(payments.status, "PENDING"));
    const pendingDuesTotal = pendingDues.reduce((sum, p) => sum + Number(p.amount), 0);

    return NextResponse.json({ entries: rows, pendingDuesTotal }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load finance entries", error);
    return NextResponse.json({ entries: [], pendingDuesTotal: 0 });
  }
}

export async function POST(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const category = body.category === "PLAYER_PAYMENT" ? "PLAYER_PAYMENT" : body.category === "EXPENSE" ? "EXPENSE" : "GENERAL";
    const title = clean(body.title, 200);
    const income = Math.max(0, Number(body.income) || 0);
    const expense = Math.max(0, Number(body.expense) || 0);
    const memberId = typeof body.memberId === "string" && body.memberId ? body.memberId : null;
    const method = clean(body.method, 60) || null;
    const note = clean(body.note, 300) || null;

    if (!title || (income === 0 && expense === 0)) return NextResponse.json({ message: "Enter a title and a non-zero amount." }, { status: 400 });
    if (category === "PLAYER_PAYMENT" && !memberId) return NextResponse.json({ message: "Select a squad member for a player payment." }, { status: 400 });

    const [created] = await db.insert(financeEntries).values({
      title, category, income: String(income), expense: String(expense), memberId, method, note, createdBy: session.email,
    }).returning({ id: financeEntries.id });
    await db.insert(auditLogs).values({ actor: session.email, action: `Finance entry added (${category})`, entityType: "FINANCE_ENTRY", entityId: created.id, details: { title, income, expense } });
    return NextResponse.json({ message: "Entry saved.", id: created.id }, { status: 201 });
  } catch (error) {
    console.error("Unable to create finance entry", error);
    return NextResponse.json({ message: "Unable to save the entry." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing entry id." }, { status: 400 });
    await db.delete(financeEntries).where(eq(financeEntries.id, id));
    await db.insert(auditLogs).values({ actor: session.email, action: "Finance entry removed", entityType: "FINANCE_ENTRY", entityId: id, details: {} });
    return NextResponse.json({ message: "Entry removed." });
  } catch (error) {
    console.error("Unable to delete finance entry", error);
    return NextResponse.json({ message: "Unable to remove the entry." }, { status: 500 });
  }
}
