import { db } from "@/db";
import { auditLogs, clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { hashSecret, verifySecret } from "@/lib/hash";
import { ADMIN_SESSION_COOKIE, createAdminSessionToken, verifyAdminSessionToken } from "@/lib/admin-session";

const SETTINGS_KEY = "adminAuth";
const DEFAULT_EMAIL = "xlkfantastic@gmail.com";
const DEFAULT_PIN = "Ahmed3715";

type AdminAuthValue = { email: string; pinHash: string };

async function getAdminAuth(): Promise<AdminAuthValue> {
  const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, SETTINGS_KEY)).limit(1);
  if (row?.value && typeof row.value.email === "string" && typeof row.value.pinHash === "string") {
    return row.value as unknown as AdminAuthValue;
  }
  // First run: seed the default admin identity provided by the club.
  const pinHash = await hashSecret(DEFAULT_PIN);
  const seeded: AdminAuthValue = { email: DEFAULT_EMAIL, pinHash };
  await db.insert(clubSettings).values({ key: SETTINGS_KEY, value: seeded }).onConflictDoUpdate({
    target: clubSettings.key,
    set: { value: seeded, updatedAt: new Date() },
  });
  return seeded;
}

// GET: return the current session state (email only, never the PIN/hash).
export async function GET(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie") || "";
    const token = cookieHeader.split(";").map(part => part.trim()).find(part => part.startsWith(`${ADMIN_SESSION_COOKIE}=`))?.split("=")[1];
    const session = verifyAdminSessionToken(token);
    if (!session) return NextResponse.json({ authenticated: false });
    return NextResponse.json({ authenticated: true, email: session.email });
  } catch (error) {
    console.error("Unable to check admin session", error);
    return NextResponse.json({ authenticated: false });
  }
}

// POST: log in with email + PIN, set a signed session cookie.
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const pin = typeof body.pin === "string" ? body.pin : "";
    if (!email || !pin) return NextResponse.json({ message: "Enter the admin email and PIN." }, { status: 400 });

    const auth = await getAdminAuth();
    const emailMatches = email === auth.email.toLowerCase();
    const pinMatches = await verifySecret(auth.pinHash, pin);
    if (!emailMatches || !pinMatches) {
      return NextResponse.json({ message: "Incorrect admin email or PIN." }, { status: 401 });
    }

    const token = createAdminSessionToken(auth.email);
    const response = NextResponse.json({ message: "Signed in.", email: auth.email });
    response.cookies.set(ADMIN_SESSION_COOKIE, token, {
      httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 12,
    });
    return response;
  } catch (error) {
    console.error("Admin login failed", error);
    return NextResponse.json({ message: "Unable to sign in right now." }, { status: 500 });
  }
}

// PUT: change the admin's own email and/or PIN. Requires the current PIN.
export async function PUT(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const currentPin = typeof body.currentPin === "string" ? body.currentPin : "";
    const newEmail = typeof body.newEmail === "string" ? body.newEmail.trim().toLowerCase() : "";
    const newPin = typeof body.newPin === "string" ? body.newPin : "";
    if (!currentPin) return NextResponse.json({ message: "Enter your current PIN to confirm this change." }, { status: 400 });
    if (!newEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) return NextResponse.json({ message: "Enter a valid email address." }, { status: 400 });
    if (newPin && newPin.length < 6) return NextResponse.json({ message: "The new PIN must be at least 6 characters." }, { status: 400 });

    const auth = await getAdminAuth();
    const valid = await verifySecret(auth.pinHash, currentPin);
    if (!valid) return NextResponse.json({ message: "Current PIN is incorrect." }, { status: 403 });

    const updated: AdminAuthValue = { email: newEmail, pinHash: newPin ? await hashSecret(newPin) : auth.pinHash };
    await db.insert(clubSettings).values({ key: SETTINGS_KEY, value: updated }).onConflictDoUpdate({
      target: clubSettings.key,
      set: { value: updated, updatedAt: new Date() },
    });
    await db.insert(auditLogs).values({
      actor: updated.email, action: "Admin login credentials updated", entityType: "ADMIN_AUTH", entityId: "adminAuth",
      details: { emailChanged: newEmail !== auth.email, pinChanged: Boolean(newPin) },
    });

    const token = createAdminSessionToken(updated.email);
    const response = NextResponse.json({ message: "Admin email and PIN updated.", email: updated.email });
    response.cookies.set(ADMIN_SESSION_COOKIE, token, {
      httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 12,
    });
    return response;
  } catch (error) {
    console.error("Unable to update admin credentials", error);
    return NextResponse.json({ message: "Unable to update admin credentials." }, { status: 500 });
  }
}

// DELETE: sign out by clearing the session cookie.
export async function DELETE() {
  const response = NextResponse.json({ message: "Signed out." });
  response.cookies.set(ADMIN_SESSION_COOKIE, "", { path: "/", maxAge: 0 });
  return response;
}
