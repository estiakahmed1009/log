import { db } from "@/db";
import { auditLogs, tournamentApplications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { escapeHtml, sendEmail } from "@/lib/mailer";

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(tournamentApplications).orderBy(desc(tournamentApplications.createdAt));
    return NextResponse.json({ applications: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load tournament applications", error);
    return NextResponse.json({ applications: [] });
  }
}

export async function PATCH(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as { id?: unknown; status?: unknown };
    const id = typeof body.id === "string" ? body.id : "";
    const status = body.status === "APPROVED" ? "APPROVED" : body.status === "REJECTED" ? "REJECTED" : null;
    if (!id || !status) return NextResponse.json({ message: "Invalid request." }, { status: 400 });

    const [application] = await db.select().from(tournamentApplications).where(eq(tournamentApplications.id, id)).limit(1);
    if (!application) return NextResponse.json({ message: "Application not found." }, { status: 404 });

    await db.update(tournamentApplications).set({ status }).where(eq(tournamentApplications.id, id));
    await db.insert(auditLogs).values({
      actor: session.email, action: `Tournament application ${status.toLowerCase()}`, entityType: "TOURNAMENT_APPLICATION", entityId: id,
      details: { teamName: application.teamName, status },
    });

    const approved = status === "APPROVED";
    await sendEmail({
      to: application.email,
      subject: approved ? "Your tournament application was approved" : "Update on your tournament application",
      html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;border:1px solid #dfe7df"><h2 style="color:#0d3a28">FANTASTIC FC</h2><p>Hello ${escapeHtml(application.managerName)},</p><p>Your tournament application for <strong>${escapeHtml(application.teamName)}</strong> has been <strong>${approved ? "approved" : "rejected"}</strong>.</p>${approved ? "<p>We'll be in touch with next steps and fixture details soon.</p>" : "<p>Thank you for your interest — feel free to apply again for future tournaments.</p>"}</div>`,
    });

    return NextResponse.json({ message: "Application updated." });
  } catch (error) {
    console.error("Unable to update tournament application", error);
    return NextResponse.json({ message: "Unable to update the application." }, { status: 500 });
  }
}
