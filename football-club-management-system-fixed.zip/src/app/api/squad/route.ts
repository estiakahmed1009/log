import { db } from "@/db";
import { members } from "@/db/schema";
import { and, asc, eq, isNotNull } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rows = await db.select({
      id: members.id,
      memberCode: members.memberId,
      name: members.fullName,
      jersey: members.jerseyNumber,
      position: members.position,
      photo: members.profilePhoto,
      isCaptain: members.isCaptain,
      matchesPlayed: members.matchesPlayed,
      goals: members.goals,
      assists: members.assists,
      rating: members.rating,
    }).from(members)
      .where(and(eq(members.status, "ACTIVE"), isNotNull(members.jerseyNumber)))
      .orderBy(asc(members.jerseyNumber));
    return NextResponse.json({ squad: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load squad", error);
    return NextResponse.json({ squad: [] });
  }
}
