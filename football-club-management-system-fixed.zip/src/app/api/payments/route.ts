import { db } from "@/db";
import { members, paymentMethods, payments } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { MEMBER_SESSION_COOKIE, verifyMemberSessionToken } from "@/lib/member-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";

// GET: the logged-in member's own payment history (identified via session cookie, not client input).
export async function GET(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie") || "";
    const token = cookieHeader.split(";").map(part => part.trim()).find(part => part.startsWith(`${MEMBER_SESSION_COOKIE}=`))?.split("=")[1];
    const session = verifyMemberSessionToken(token);
    if (!session) return NextResponse.json({ message: "Sign in required." }, { status: 401 });

    const rows = await db.select({
      id: payments.id, feeType: payments.feeType, amount: payments.amount, status: payments.status,
      transactionId: payments.transactionId, methodId: payments.paymentMethodId, createdAt: payments.createdAt,
      verifiedAt: payments.verifiedAt,
    }).from(payments).where(eq(payments.memberId, session.memberId)).orderBy(desc(payments.createdAt));

    const methodRows = await db.select({ id: paymentMethods.id, name: paymentMethods.name }).from(paymentMethods);
    const methodMap = new Map(methodRows.map(m => [m.id, m.name]));
    const list = rows.map(r => ({ ...r, method: (r.methodId && methodMap.get(r.methodId)) || "—" }));

    return NextResponse.json({ payments: list }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load member payments", error);
    return NextResponse.json({ payments: [] });
  }
}

export async function POST(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie") || "";
    const token = cookieHeader.split(";").map(part => part.trim()).find(part => part.startsWith(`${MEMBER_SESSION_COOKIE}=`))?.split("=")[1];
    const session = verifyMemberSessionToken(token);
    if (!session) return NextResponse.json({ message: "Sign in required." }, { status: 401 });

    const body = (await request.json()) as Record<string, unknown>;
    const transactionId = clean(body.transactionId, 120).toUpperCase();
    const feeType = clean(body.feeType, 80);
    const methodName = clean(body.methodName, 60);
    const amount = Number(body.amount);
    const screenshot = typeof body.screenshot === "string" ? body.screenshot : "";

    if (!feeType || !methodName || !/^[A-Z0-9-]{5,120}$/.test(transactionId) || !Number.isFinite(amount) || amount <= 0 || amount > 100000) {
      return NextResponse.json({ message: "Enter valid payment information and transaction ID." }, { status: 400 });
    }
    if (screenshot && (!screenshot.startsWith("data:image/") || screenshot.length > 2_000_000)) {
      return NextResponse.json({ message: "Payment proof must be a JPG/PNG image under 1.5 MB." }, { status: 400 });
    }

    // Identify the paying member from their own session — never trust a client-supplied member code here,
    // or anyone could submit payments (and pollute payment history) under someone else's account.
    const [member] = await db.select({ id: members.id, status: members.status }).from(members).where(eq(members.id, session.memberId)).limit(1);
    if (!member || member.status !== "ACTIVE") return NextResponse.json({ message: "Only active members can submit payments." }, { status: 403 });
    const [method] = await db.select({ id: paymentMethods.id }).from(paymentMethods).where(and(eq(paymentMethods.name, methodName), eq(paymentMethods.enabled, true))).limit(1);
    if (!method) return NextResponse.json({ message: "This payment method is not currently enabled." }, { status: 400 });

    const [created] = await db.insert(payments).values({
      memberId: member.id,
      paymentMethodId: method.id,
      feeType,
      amount: amount.toFixed(2),
      transactionId,
      screenshotUrl: screenshot || null as string | null,
      status: "PENDING",
    }).returning({ id: payments.id });
    return NextResponse.json({ message: "Payment submitted for admin verification.", paymentId: created.id, status: "PENDING" }, { status: 201 });
  } catch (error) {
    if ((error as { code?: string }).code === "23505") return NextResponse.json({ message: "This transaction ID has already been submitted." }, { status: 409 });
    console.error("Payment submission failed", error);
    return NextResponse.json({ message: "Unable to submit payment." }, { status: 500 });
  }
}
